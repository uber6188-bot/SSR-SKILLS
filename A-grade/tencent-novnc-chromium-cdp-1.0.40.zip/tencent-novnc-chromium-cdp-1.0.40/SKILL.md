---
name: tencent-novnc-chromium-cdp
description: "做自动发抖音、自动发小红书等等各大平台的网页自动化，还在被滑块、验证码、人机验证卡到任务翻车、反复失败？试试这个一键部署的远程可视化浏览器：Linux（云服务器/NAS/本地）noVNC + Chromium + CDP 三合一，Windows 本机 Edge/Chrome CDP 一键接管，让AI Agent和你共享同一个浏览器，服务器无图形界面也能可视化操控，登录、过验证全靠人工兜底，再也不怕自动化卡壳，发平台内容一次稳到底！"
---

## 📖 使用教程

**两步搞定，全程不用动手。**

**第一步：安装本技能**

点击上方「安装方式」按钮一键安装，或复制以下提示词发送给 AI Agent 自动安装：

```
请先检查是否已安装 SkillHub 商店，若未安装，请根据 https://skillhub.cn/install/skillhub.md 安装 SkillHub 商店，但是只安装 CLI，然后安装 tencent-novnc-chromium-cdp 技能。若已安装，则直接安装 tencent-novnc-chromium-cdp 技能。
```

**第二步：使用**

对 AI Agent 发送提示词：

```
使用 tencent-novnc-chromium-cdp 技能
```

AI Agent 收到后会全自动处理：检测系统环境 → 安装依赖 → 启动 Chromium 远程浏览器 → 配置开机自启 → 先发 noVNC 地址和密码等核心信息 → 最后截图确认。全程不需要你敲任何命令。

> 💡 部署完成后遇到登录、验证码、滑块，在 noVNC 页面上手动操作即可，完成后告诉 AI 继续。

# noVNC + Chromium + CDP 远程可视可控浏览器（Linux / Windows 双平台）

## 技能简介

本技能同时支持 Linux 和 Windows，覆盖云服务器与本地环境：Linux 服务器上部署 noVNC + Chromium 远程可视化浏览器，Windows 本机通过 CDP 远程调试直接接管 Edge/Chrome 浏览器。

它解决的是传统 Headless 浏览器自动化最常见的痛点：遇到登录、扫码、滑块、验证码、风控验证时，AI 可以暂停并让用户在 noVNC 页面中手动完成验证，验证通过后再继续由 AI 接管操作。

适合用于抖音创作者中心、小红书、微博、番茄小说、各类后台管理系统等需要"AI 自动化 + 人工验证协作"的网页场景。

## 核心能力

- **可视化浏览器**：Chromium 运行在 Xvfb 虚拟屏幕上，用户可通过 noVNC 网页实时查看画面。
- **AI 可控**：Agent 通过 CDP 连接 `127.0.0.1:9223`，可执行打开网页、点击、输入、读取页面、截图等操作。
- **人机协作**：遇到登录、二维码、滑块、验证码时，用户可在 noVNC 中手动处理，处理完成后 AI 继续执行。
- **权限预检**：安装前先确认 root/sudo 权限，权限不足时主动提醒用户授权方式，避免半安装状态。
- **安全边界**：默认只建议开放 noVNC 的 `6080/tcp`，CDP 调试端口 `9223/tcp` 不建议暴露到公网。
- **完成反馈**：部署完成后，Agent 必须先主动发送 noVNC 访问地址、访问密码、开机自启状态和端口开放提醒；截图作为最后一步补充确认发送，截图失败不得阻塞前面的核心信息。
- **Windows 本机模式**：Agent 自动启动 Edge/Chrome 远程调试端口，通过 CDP 接管浏览器，本机屏幕实时可见，截取当前页面反馈，无需安装额外组件。

部署完成后，Agent 通过 CDP 控制浏览器（详见「七、通过 CDP 控制浏览器」）。

> ⚠️ **铁律（最高优先级）**：本技能部署完成后，用户让 AI Agent「打开浏览器 / 看网页 / 截图 / 点击 / 登录」等任何浏览器操作，**默认必须使用本技能部署的 CDP 浏览器**（`127.0.0.1:9223`）。Linux 下即 noVNC 里 `:99` 上的 Chromium，Windows 下即用户本机屏幕上的 Edge/Chrome。**禁止使用 Agent 自带的内置 headless 浏览器或临时拉起其他实例**，否则用户和 Agent 看到的画面不同频。完整规则见「十一、重要原则」。

## 服务器配置要求与端口提醒

### 开始部署前必须先提醒用户

本技能需要安装系统依赖、下载 noVNC、启动 Chromium 图形浏览器和 VNC 转发服务，步骤较多。Agent 在正式执行安装前，应先发一条简短提醒，让用户知道部署需要等待一段时间。

推荐提醒话术（根据检测到的环境类型选择对应话术）：

**CLOUD（云服务器）环境：**
```text
开始部署 noVNC + Chromium + CDP 远程可视可控浏览器。

重要提示：服务器建议至少 2H4G。
端口提醒：必须在云服务器安全组放行 6080/tcp；5900/tcp 为高级用途，可选开放，开放时建议限制来源 IP。9223/tcp（CDP 调试端口）仅供 Agent 本机使用，不建议对公网开放。
预计耗时：通常约 5-15 分钟；如果服务器配置较低、网络较慢或需要安装大量依赖，可能需要 20-30 分钟。部署过程中请耐心等待，不要中断。
Token 提醒：顺利部署预计消耗约 2万-5万 tokens；如果网络较慢、依赖安装失败、需要自动修复或多次重试，可能消耗 5万-10万+ tokens，实际以执行过程为准。开始前请确认当前会话/套餐剩余 Token 必须大于预计消耗，建议至少预留 10万 tokens 以上，避免部署过程中因 Token 不足中断。
进度提醒：安装过程中我会每 30 秒检查一次进度和服务状态，如有常见问题会先自动修复；并且每分钟向你汇报一次部署进度，直到安装成功。
```

**NAS 环境：**
```text
开始部署 noVNC + Chromium + CDP 远程可视可控浏览器。

重要提示：NAS 建议至少 2H4G。
端口提醒：部署完成后通过局域网地址访问。如需外网访问，请在路由器上设置端口转发 6080 TCP → <NAS_IP>。9223/tcp（CDP 调试端口）仅供 Agent 本机使用，不建议开放。
预计耗时：通常约 5-15 分钟；如果 NAS 性能较低、网络较慢，可能需要 20-30 分钟。部署过程中请耐心等待，不要中断。
Token 提醒：顺利部署预计消耗约 2万-5万 tokens；实际以执行过程为准。建议至少预留 10万 tokens 以上。
进度提醒：安装过程中我会每 30 秒检查一次进度并每分钟汇报，直到安装成功。
```

**LOCAL（本机 Linux）环境：**
```text
开始部署 noVNC + Chromium + CDP 远程可视可控浏览器。

重要提示：本机建议至少 2H4G。
端口提醒：部署完成后通过内网地址访问。如需外网访问，请在路由器上设置端口转发 6080 TCP → <本机IP>。9223/tcp（CDP 调试端口）仅供 Agent 本机使用，不建议开放。
预计耗时：通常约 5-15 分钟。部署过程中请耐心等待，不要中断。
Token 提醒：顺利部署预计消耗约 2万-5万 tokens。
进度提醒：安装过程中我会每 30 秒检查一次进度并每分钟汇报，直到安装成功。
```

如果检测到服务器配置低于 2H4G，应额外提醒用户可能出现 Chromium 卡顿、白屏或被系统杀掉的问题。

### 安装过程进度监控与自动修复

部署本技能时，Agent 不应长时间静默等待。正式开始安装后，应执行以下进度监控规则：

1. **每 30 秒检查一次进度**：检查当前安装命令是否仍在运行，查看最近日志，确认是否卡在依赖安装、软件下载、服务启动或端口监听阶段。
2. **每 30 秒检查关键状态**：重点检查 `Xvfb`、`chromium`、`x11vnc`、`websockify/noVNC` 是否启动，`6080/tcp` 和 `9223/tcp` 是否正常监听。
3. **常见问题优先自动修复**：如依赖缺失、包管理锁、残留旧进程、端口占用、Chromium 启动失败、noVNC 未下载完整等，应先尝试清理旧进程、重新安装依赖、重新启动服务或重新下载组件。
4. **每分钟汇报一次进度**：向用户发送简短消息，说明当前阶段，例如“正在安装系统依赖”“正在启动 Chromium”“正在检测 6080 端口”“正在准备完成信息”“正在执行最后截图确认”。
5. **不要刷屏**：进度消息保持简短，每分钟一次即可；只有遇到需要用户处理的问题时才立即额外提醒。
6. **直到成功或需要人工介入**：持续监控并汇报，直到 noVNC 地址可访问、Chromium 已打开百度页面、核心完成信息已发送、最后截图已发送或已明确报告截图失败原因；如果自动修复失败，应明确告诉用户失败步骤、原因和下一步需要用户做什么。

安装过程自动监控进度，失败时自动重试。完成后自动验证 Chromium 和 noVNC 可用。

### 最低服务器配置

本技能会启动 Chromium 图形浏览器、虚拟显示器和 VNC 转发服务，资源占用高于普通命令行脚本。建议服务器配置不低于：

```text
最低推荐：2 核 CPU / 4GB 内存（2H4G）
系统推荐：Debian 10+ / Ubuntu 20.04+
磁盘建议：至少预留 5GB 可用空间
```

低于 2H4G 的服务器也可能启动成功，但容易出现 Chromium 卡顿、页面白屏、验证码页面 CPU 飙高、浏览器被系统杀掉等问题。

### 端口开放说明

必须开放：

- `6080/tcp`：noVNC 网页访问端口。用户通过 `http://<服务器公网IP>:6080/vnc.html` 打开远程 Chromium 浏览器。

可选开放：

- `5900/tcp`：VNC 原生端口。默认仅供本机 websockify 转发使用，一般不需要公网开放；只有需要用 VNC 客户端直连时才考虑开放，并建议限制来源 IP。
- `9223/tcp`：Chromium CDP 调试端口。默认仅供 Agent 在服务器本机控制浏览器使用；只有明确需要远程调试时才考虑开放，并必须限制来源 IP，避免浏览器被他人接管。

开放端口：noVNC(6080)、VNC(5900)、Chromium CDP(9222)。云服务器需在安全组/防火墙放行。

## 适用场景

| 场景 | 说明 |
|------|------|
| 抖音/小红书自动发布 | 通过 noVNC 登录账号，CDP 控制发布流程 |
| 滑块/验证码处理 | noVNC 可视化界面手动处理，CDP 继续自动化 |
| 无头服务器自动化 | Linux 服务器无图形界面，通过 noVNC 远程操控 |
| 多账号管理 | 多个 Chromium 实例，不同端口，独立 noVNC |
| Windows 本机接管 | 直接连接 Edge/Chrome CDP，无需部署 |

## 零、系统检测（第一步）

检测操作系统(Linux/Windows)、发行版(Ubuntu/Debian/CentOS)、桌面环境、已安装的浏览器。Linux 服务器模式 vs Windows 本机模式自动判断。

## 一、检查系统与服务器配置

```bash
cat /etc/os-release | head -3
uname -m
nproc
free -h
df -h /
```

推荐环境：Debian 10+ / Ubuntu 20.04+ / 较新的 Linux 发行版。

配置要求：建议至少 **2 核 CPU / 4GB 内存（2H4G）**。如果内存低于 4GB，Agent 应先提醒用户可能出现 Chromium 卡顿、白屏或被系统杀掉的问题，再继续安装。

## 二、权限预检（必须）

检查 root/sudo 权限、系统架构(x86_64/arm64)、可用内存(≥1GB)、磁盘空间(≥2GB)。权限不足时提示用户切换到 root 或使用 sudo。

## 三、安装依赖

Debian / Ubuntu：

```bash
apt update && apt upgrade -y
apt install -y xvfb x11vnc git python3-pip curl wget ca-certificates
```

### 安装 Chromium/Chrome

优先安装系统包管理器提供的 Chromium（deb版），如不可用则降级到 snap 版或 Google Chrome。

```bash
# 优先：deb 版
apt install -y chromium-browser || apt install -y chromium

# 降级：snap 版
snap install chromium

# 备选：Google Chrome
wget -q -O /tmp/chrome.deb https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
apt install -y /tmp/chrome.deb
```

## 四、开放端口

端口放行规则随环境类型不同而变化。Agent 必须根据前面确定的环境类型（`$ENV_TYPE`）选择对应的防火墙指令：

**CLOUD（云服务器）：**
```bash
# 系统防火墙放行 noVNC
ufw allow 6080/tcp || true
ufw reload || true

# 云厂商安全组也要放行：
# - 6080/tcp：noVNC 网页访问端口
# - 9223/tcp：CDP 调试端口，**不建议对公网开放**，仅供 Agent 本机 127.0.0.1 使用
```

**NAS：**
```bash
# NAS 部署：内网直接访问，无需操作防火墙。
# 如需外网访问：在路由器上设置端口转发 6080 TCP → <NAS_IP>
# 9223/tcp CDP 端口仅供本机，不转发。
echo "NAS 环境：noVNC 通过内网地址访问。如需外网访问，请在路由器做端口转发 6080。"
```

**LOCAL（本机 Linux）：**
```bash
# 系统防火墙放行 noVNC
ufw allow 6080/tcp || true
ufw reload || true

# 如需外网访问：在路由器上设置端口转发 6080 TCP → <本机IP>
# 9223/tcp CDP 端口仅供本机，不转发。
```

## 五、创建一键启动脚本

### 1. 生成 noVNC 访问密码（必须）

为防止 noVNC 端口（6080）被裸暴露公网导致浏览器被任何人接管，启动前必须生成一个 **8 位随机密码**（字母+数字混合），并让 x11vnc 用密码模式启动。Agent 必须把这个密码原文保存到固定路径，方便部署后回复给用户。

```bash
# 8 位随机密码（字母+数字混合）
NOVNC_PASS=$(tr -dc 'A-Za-z0-9' </dev/urandom | head -c 8)
echo -n "$NOVNC_PASS" > /root/.novnc_password
chmod 600 /root/.novnc_password

# 用 x11vnc 自己的工具生成 VNC 密码文件
x11vnc -storepasswd "$NOVNC_PASS" /root/.vncpasswd
chmod 600 /root/.vncpasswd

echo "noVNC 访问密码已生成：$NOVNC_PASS"
echo "明文存储于：/root/.novnc_password（仅 root 可读）"
echo "VNC 密码文件：/root/.vncpasswd"
```

> 后续 x11vnc 启动必须使用 `-rfbauth /root/.vncpasswd`，**不再使用 `-nopw`**。

### 2. 写入启动脚本

```bash
cat > /root/start-remote-browser.sh << 'SCRIPT'
#!/bin/bash
export DISPLAY=:99
Xvfb :99 -screen 0 1920x1080x24 &
sleep 2
x11vnc -display :99 -forever -nopw -rfbport 5900 &
sleep 2
cd /opt/noVNC && ./utils/novnc_proxy --vnc localhost:5900 --listen 6080 &
sleep 3
chromium --no-sandbox --disable-gpu --remote-debugging-port=9222 --remote-debugging-address=0.0.0.0 --window-size=1920,1080 --display=:99
SCRIPT
chmod +x /root/start-remote-browser.sh
```

## 六、启动远程浏览器

```bash
bash /root/start-remote-browser.sh
```

启动完成后，用户访问：

```text
http://<服务器IP>:6080/vnc.html
```

CDP 检查地址：

```bash
curl -s http://127.0.0.1:9223/json/version
curl -s http://127.0.0.1:9223/json
```

**⚠️ 部署到这一步时，手动脚本启动的 Chromium 还在后台运行。接下来配置 systemd 自启前，必须先杀掉手动进程，避免两个 Chromium 实例抢同一个 `--user-data-dir`，导致标签页不断堆叠。**

```bash
pkill -9 -f "(chromium|chrome).*remote-debugging-port=9223" 2>/dev/null || true
sleep 2
```

> 否则会出现：手动脚本开一个百度 → systemd 自启又开一个 → OOM 重启再开一个，堆成三个百度页。

## 六-bis、配置开机自启（必须）

创建 systemd 服务实现开机自动启动：

```bash
cat > /etc/systemd/system/remote-browser.service << 'EOF'
[Unit]
Description=Remote Browser (Xvfb + noVNC + Chromium)
After=network.target

[Service]
Type=simple
ExecStartPre=/bin/bash -c 'Xvfb :99 -screen 0 1920x1080x24 &'
ExecStartPre=/bin/bash -c 'sleep 2 && x11vnc -display :99 -forever -nopw -rfbport 5900 &'
ExecStartPre=/bin/bash -c 'sleep 3 && cd /opt/noVNC && ./utils/novnc_proxy --vnc localhost:5900 --listen 6080 &'
ExecStart=/bin/bash -c 'sleep 5 && chromium --no-sandbox --disable-gpu --remote-debugging-port=9222 --remote-debugging-address=0.0.0.0 --window-size=1920,1080 --display=:99'
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable remote-browser
systemctl start remote-browser
```

验证：`systemctl status remote-browser`

## 七、CDP 控制浏览器（参考代码）

```python
import json, asyncio, websockets

async def cdp_command(ws_url, method, params=None):
    async with websockets.connect(ws_url) as ws:
        msg = {"id": 1, "method": method, "params": params or {}}
        await ws.send(json.dumps(msg))
        return json.loads(await ws.recv())

# 获取标签页列表
tabs = json.loads(urlopen("http://localhost:9222/json").read())
ws_url = tabs[0]["webSocketDebuggerUrl"]

# 导航到目标页面
asyncio.run(cdp_command(ws_url, "Page.navigate", {"url": "https://example.com"}))
```

## 八、回复模板

收尾时必须先发送核心完成信息，再把截图作为最后一步发送。严禁因为截图生成或发送失败，导致 noVNC 地址、访问密码等核心信息没有发出去。

### 1. 发送前准备

运行脚本获取 noVNC 地址：

```bash
# 根据环境类型选择 IP（ENV_TYPE 在「零、系统检测」步骤中已设置）
if [ "$ENV_TYPE" = "CLOUD" ]; then
  # 云服务器：优先使用公网 IP
  PUBLIC_IP=$(curl -4 -s https://ifconfig.me 2>/dev/null || curl -4 -s https://api.ipify.org 2>/dev/null || true)
  if [ -n "$PUBLIC_IP" ]; then
    NOVNC_URL="http://${PUBLIC_IP}:6080/vnc.html"
  else
    LOCAL_IP=$(hostname -I | awk '{print $1}')
    NOVNC_URL="http://${LOCAL_IP}:6080/vnc.html"
  fi
else
  # NAS / 本地 Linux：直接使用内网 IP
  LOCAL_IP=$(hostname -I | awk '{print $1}')
  NOVNC_URL="http://${LOCAL_IP}:6080/vnc.html"
fi
echo "$NOVNC_URL"
echo "ENV_TYPE=$ENV_TYPE"
```

读取访问密码：

```bash
cat /root/.novnc_password
```

### 2. 发送顺序铁律（最高优先级）

1. **先发核心完成信息**：必须先把 noVNC 地址、访问密码、浏览器状态、开机自启状态、端口提醒和验证码处理说明发送给用户。
2. **截图最后发送**：核心信息发出后，再截图并发送图片。截图只是可视化确认，不得阻塞核心信息。
3. **截图失败处理**：如果截图命令失败、图片复制失败或平台发图失败，不允许吞掉核心信息；应先保证用户拿到访问入口，再说明截图失败原因并尝试修复/重试。
4. **禁止只给路径**：截图成功生成后必须通过当前平台的图片/文件能力发送，不能只说“截图在 `/tmp/remote-browser.png`”。
5. **单条回复场景**：如果当前 Agent 只能发一条最终回复，必须把文本核心信息放在前面，截图标签放在最后面。

核心顺序：先发核心完成信息（地址+密码），再截图确认。截图失败不能阻塞信息发送。

### 3. Linux 模式回复模板

```
✅ 远程浏览器部署完成！

🔗 noVNC 地址：http://<服务器IP>:6080/vnc.html
🔑 访问密码：<生成的密码>
📡 CDP 地址：ws://<服务器IP>:9222

📋 使用说明：
1. 浏览器打开 noVNC 地址
2. 输入密码连接
3. 登录需要操作的平台（抖音/小红书等）
4. 验证码/滑块在 noVNC 中手动处理
5. AI Agent 通过 CDP 控制浏览器

⚠️ 注意事项：
- 首次登录需手动验证
- CDP 端口(9222)仅供本地或内网访问
- 开机自启已配置，重启自动恢复
```

### 4. Windows 模式回复

```text
✅ 浏览器已完全由 AI Agent 控制。

- 浏览器：Edge/Chrome（CDP 端口 9223）
- 你可以在屏幕上看到所有操作，随时手动接管
- 请勿关闭这个浏览器窗口
- 如果遇到登录、验证码、滑块，你直接操作即可，完成后告诉我继续
```

Windows 模式也必须先发送上面的接管完成信息，再把截图作为最后一步发送。截图通过 CDP `Page.captureScreenshot`（完整代码见「十二-3 截图当前页面」）；截图失败不得影响接管完成信息。

## 九、验证清单

### Linux 模式验证

```bash
ss -tlnp | grep -E '6080|5900|9223'
curl -s -o /dev/null -w '%{http_code}\n' http://127.0.0.1:6080/vnc.html
curl -s http://127.0.0.1:9223/json/version
```

应满足：

- `6080` 正在监听
- `5900` 正在监听本机 VNC
- `9223` 正在监听 CDP
- `vnc.html` 返回 `200`
- 用户能在浏览器看到远程 Chromium 画面

### Windows 模式验证

```bash
curl -s http://127.0.0.1:9223/json/version
curl -s http://127.0.0.1:9223/json
```

应满足：

- `9223` 正在监听 CDP
- `json/version` 返回浏览器信息
- `json` 返回至少一个 page 类型的标签
- 用户本机屏幕上能看到 Edge/Chrome 浏览器窗口

## 十、常见问题

| 问题 | 解决方案 |
|------|----------|
| noVNC 白屏 | 重启 Xvfb: `pkill Xvfb && Xvfb :99 -screen 0 1920x1080x24 &` |
| CDP 连接失败 | 检查 9222 端口: `curl http://localhost:9222/json` |
| VNC 无法连接 | 检查 5900 端口和密码配置 |
| Chromium 崩溃 | 检查内存，降低分辨率或关闭不必要标签 |
| 开机自启不生效 | 检查 systemd: `systemctl status remote-browser` |
