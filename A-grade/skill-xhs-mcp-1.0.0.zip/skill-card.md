## Description: <br>
XiaoHongShu (RED/XHS) automation assistant via local MCP service. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[weznai](https://clawhub.ai/user/weznai) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and automation users can use this skill to connect an agent to a local XiaoHongShu MCP service for login checks, content discovery, social interactions, and image or video publishing. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can control a real XiaoHongShu account and perform public actions such as likes, comments, replies, and posts. <br>
Mitigation: Require manual approval before public account actions and use a low-risk account during setup and testing. <br>
Risk: The skill depends on an external, unpinned local xhs-mcp-service and its npm dependencies. <br>
Mitigation: Review the external service repository and dependency tree before installation or update. <br>
Risk: The local MCP service can expose account capabilities to local clients. <br>
Mitigation: Keep the service reachable only by trusted local clients and understand that deleting cookies removes the stored login session. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/weznai/skill-xhs-mcp) <br>
- [xhs-mcp-service repository](https://github.com/weznai/xhs-mcp-service.git) <br>


## Skill Output: <br>
**Output Type(s):** [guidance, shell commands, code, configuration] <br>
**Output Format:** [Markdown with inline shell commands and JavaScript examples] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [Requires Node.js 18 or newer and a local xhs-mcp-service endpoint on localhost:18060.] <br>

## Skill Version(s): <br>
1.0.0 (source: server release metadata) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
