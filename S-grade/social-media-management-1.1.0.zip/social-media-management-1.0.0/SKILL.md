---
name: social-media-management
description: B2B content writing with daily workflows and batching systems across Sales/HR/Fintech/Ops Tech
---
## Multi-Dimensional Navigator

Content writing varies by industry, stage, and role. Use this navigator to find the right approach.

| Dimension | Options |
|-----------|---------|
| **Industry** | Sales Tech, HR Tech, Fintech, Operations Tech |
| **Stage** | Series A (startup), Series B (scaling), Series C+ (enterprise) |
| **Role** | Founder (aggressive), Employee (professional), Enterprise (compliant) |
| **Market** | India, US, Global |

**How to use:** Identify your industry → stage → role → find matching section below.

## Quick Navigation

| Scenario | Reference File |
|----------|---------------|
| Sales Tech Founder | `references/a1-sales-tech-series-a.md` |
| Sales Tech Team | `references/a2-sales-tech-series-b.md` |
| HR Tech Sensitive Topics | `references/b1-hr-tech-series-a.md` |
| Fintech Compliance | `references/c1-fintech-series-a.md` |
| Operations Tech Niche | `references/d1-ops-tech.md` |

## Role-Based Content Workflows

### Founder Content (Full Autonomy)
- Post freely, no approval needed
- Aggressive positioning allowed
- Personal voice = brand voice
- Direct competitor mentions OK

### Employee Content (Approval Required)
- Manager approval before posting
- Professional tone, no controversial takes
- Company-aligned messaging only
- No direct competitor attacks

### Enterprise Employee (Corporate Comms Control)
- Legal/compliance review mandatory
- Brand guidelines strictly followed
- Pre-approved templates only
- No personal opinions on company topics

## Geography-Specific Content

| Market | Tone | Posting Time | Platform Focus |
|--------|------|-------------|----------------|
| India | Professional, aspirational | 9-11 AM IST | LinkedIn |
| US | Direct, data-driven | 8-10 AM EST | LinkedIn, Twitter |
| Global | Neutral, inclusive | Adapt to each market | LinkedIn |

## Common Content Mistakes

| Mistake | Fix |
|---------|-----|
| Same writing style for all industries | Adapt tone: Sales=aggressive, HR=professional, Fintech=compliant |
| No approval process when needed | Employee/enterprise must get sign-off |
| Publishing at wrong times | Check timezone: India 9-11AM, US 8-10AM |
| Ignoring compliance in Fintech | Legal review mandatory for all posts |

## Prompt Templates

| Scenario | Template |
|----------|----------|
| Sales Tech Founder | "Write a [post type] about [topic]. Tone: aggressive, direct. Include data. Mention competitors." |
| HR Tech VP | "Write a [post type] about [topic]. Tone: professional, empathetic. Cite research. No controversial claims." |
| Fintech Founder | "Write a [post type] about [topic]. Tone: confident but compliant. Include disclaimers. No financial advice." |

## Worked Examples

See `references/examples.md` for detailed multi-dimensional scenarios including:
- Sales Tech Founder, Series A, aggressive post
- HR Tech VP, Series B, sensitive topic (layoffs)
- Fintech Founder, Series A, regulatory update

## Tool Comparison Matrix

| Tool | Best For | Pricing |
|------|----------|---------|
| LinkedIn | B2B professional content | Free + Premium |
| Twitter/X | Real-time engagement | Free |
| Blog/SEO | Long-form thought leadership | Free + hosting |
| Email | Nurture sequences | Varies |
| Video (YouTube) | Product demos, tutorials | Free |

## Quick Reference Cards

### By Industry Tone
| Industry | Tone | Do | Don't |
|----------|------|-----|-------|
| Sales Tech | Aggressive, direct | Mention competitors, use data | Be vague, avoid specifics |
| HR Tech | Professional, empathetic | Cite research, be sensitive | Make light of layoffs |
| Fintech | Confident, compliant | Include disclaimers | Give financial advice |
| Ops Tech | Niche, technical | Focus on use cases | Use buzzwords |

### By Company Stage
| Stage | Content Volume | Approval | Focus |
|-------|---------------|----------|-------|
| Series A | 3x/week, founder-led | Minimal | Growth, customers |
| Series B | Daily, team-produced | Manager sign-off | Brand, thought leadership |
| Series C+ | Daily, multiple authors | Legal review | Category ownership |

### Approval Workflow
| Role | Approval Needed | Turnaround |
|------|----------------|------------|
| Founder | No | Immediate |
| Manager | Yes (peer review) | 24 hours |
| Enterprise | Yes (legal + comms) | 48-72 hours |

