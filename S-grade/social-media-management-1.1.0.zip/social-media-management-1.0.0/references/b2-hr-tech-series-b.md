## **B2: HR Tech @ Series B (Team Content, Brand Voice)**

### **Your Reality Check:**

```
COMPANY PROFILE:
- Size: $12M-40M ARR, 200-600 employees
- Stage: Series B
- You: Director of Content or VP Marketing
- Team: Writer + Designer (HR background preferred)
- Content goal: Category thought leadership
- Publishing: 3-5× per week
- Approval: Manager/Founder for sensitive topics
- Budget: $5K-15K/month
```

### **Series B HR Tech: Elevated Professional Content**

```
TEAM STRUCTURE:

CONTENT DIRECTOR (You):
- Strategy (topics, angles, positioning)
- Stakeholder management (Founder/CHRO, Sales, Product)
- Approval (final sign-off)
- Metrics (engagement, brand awareness, pipeline)

HR CONTENT WRITER (1 FTE):
- Ideally: Background in HR or People Ops
- Research (SHRM, Josh Bersin, academic studies)
- Writing (blog posts, LinkedIn, thought leadership)
- Editing (professional quality)

DESIGNER (Part-time):
- People-focused visuals (diverse, inclusive imagery)
- Data visualization (engagement benchmarks, survey results)
- Brand consistency (HR Tech = warm, professional aesthetic)

FOUNDER/CHRO (Guest Voice):
- 1× per week under their name
- Strategic POV, industry trends
- Vulnerable shares (culture challenges)

APPROVAL WORKFLOW:

STANDARD POST (Research summary, framework):
Writer → Content Director → Publish
Timeline: Same day to 1 day

STRATEGIC POST (Industry POV, predictions):
Writer → Content Director → VP Marketing → Publish
Timeline: 2-3 days

SENSITIVE POST (Layoffs, DE&I, compensation):
Writer → Content Director → VP Marketing → Founder/CHRO → Legal (if needed)
Timeline: 3-7 days

WHY STRICTER APPROVAL FOR HR TECH:
- People topics = sensitive (layoffs, DE&I, mental health)
- Legal risk (employment law, EEOC, GDPR)
- Reputation risk (HR community is small)
- Every post reflects on company culture (practice what you preach)
```

### **Series B HR Tech: Original Research Content**

```
QUARTERLY RESEARCH INITIATIVES:

Q1: "THE STATE OF EMPLOYEE ENGAGEMENT 2026"
- Survey: 500-1,000 HR leaders
- Partner: SHRM chapter for distribution
- Content series:
  * Week 1: "Early findings: What's changing in engagement"
  * Week 2: "Hybrid work impact on engagement [data]"
  * Week 3: "Manager effectiveness = #1 driver [deep dive]"
  * Week 4: "Full report release + webinar"

Production:
- Survey: $2K-5K (Typeform, SurveyMonkey)
- Design: $1K-3K (report design)
- Writer: 40 hours (analysis + writing)
- Timeline: 6-8 weeks

Impact:
- 800-1,500 new followers
- 50-100 inbound leads
- Media coverage (HR Dive, HRExecutive)
- Sales enablement (differentiation)

Q2: "MANAGER EFFECTIVENESS BENCHMARKS"
- Your product data: Anonymized manager scores
- Customer interviews: 20 case studies
- Academic validation: Partner with university

Q3: "HYBRID WORK BEST PRACTICES [2026]"
- Timely, high-interest
- Multi-company research
- Expert commentary (industrial-organizational psychologists)

Q4: "HR TECH STACK SURVEY"
- What tools do CHROs use?
- Integration challenges
- Budget benchmarks
- Vendor satisfaction
```

### **Series B HR Tech: Sensitive Topic Guidelines**

```
LAYOFFS / WORKFORCE REDUCTIONS:

IF YOUR COMPANY IS LAYING OFF:
❌ Don't post about it personally until official announcement
❌ Don't hint or foreshadow ("Hard times ahead...")
✅ Wait for official company communication
✅ Then: Can share empathetic reflection (after announcement)

IF WRITING ABOUT LAYOFFS GENERALLY:
✅ Empathetic tone (people are losing jobs)
✅ Practical guidance (for HR leaders navigating this)
✅ Mental health resources
❌ "Layoffs are good actually" (insensitive)
❌ Naming companies doing layoffs (unless public news)

EXAMPLE POST (After Your Company Layoff):
"We had to make difficult decisions this week.
As someone who had to deliver the news to incredible people,
here's what I learned about navigating reductions with empathy:

1. Clarity (people deserve straightforward communication)
2. Dignity (everyone gets proper support)
3. Transparency (explain the why, not just the what)

This is hard. If you're going through this, I see you."

TONE: Humble, empathetic, human

---

DIVERSITY, EQUITY & INCLUSION (DE&I):

APPROPRIATE CONTENT:
✅ Share research on DE&I impact
✅ Best practices (blind resume reviews, structured interviews)
✅ Personal commitment ("We're working on...")
✅ Progress + transparency ("Here's where we are...")

INAPPROPRIATE CONTENT:
❌ Virtue signaling ("We're the most diverse!")
❌ Tokenism (featuring one diverse employee repeatedly)
❌ Oversimplifying complex topics
❌ Speaking over marginalized communities

GUIDANCE:
- If you're not from the community, amplify voices that are
- Focus on systems/policies (not individual stories without permission)
- Be honest about challenges (not just wins)
- Legal review recommended (DE&I = potential discrimination claims)

---

MENTAL HEALTH:

APPROPRIATE CONTENT:
✅ Normalize mental health discussions
✅ Share company resources (EAP, mental health days)
✅ Manager training on recognizing signs
✅ Empathetic leadership (sharing your own experience)

INAPPROPRIATE CONTENT:
❌ Armchair diagnosing ("I think X has anxiety")
❌ Oversharing personal struggles (maintain professionalism)
❌ Suggesting company programs replace professional help

DISCLAIMERS:
Always include: "If you're struggling, please seek professional help.
Resources: [crisis hotline, EAP, etc.]"
```

---
