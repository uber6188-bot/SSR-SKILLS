## **B1: HR Tech @ Series A (Founder, Professional Voice Required)**

### **Your Reality Check:**

```
COMPANY PROFILE:
- Size: $2M-8M ARR, 20-80 employees
- Stage: Series A
- You: Founder (often ex-CHRO background)
- Content goal: Build trust, establish expertise
- Publishing: 2-3× per week (quality > quantity)
- Voice: Professional, empathetic, never aggressive
```

### **Why HR Tech Content is FUNDAMENTALLY DIFFERENT:**

```
SALES TECH CONTENT:
✅ Aggressive, contrarian takes
✅ "Gong is wrong about X"
✅ Challenge incumbents publicly
✅ Data-driven, ROI-focused
Risk: Low (worst case = lose followers)

HR TECH CONTENT:
❌ NEVER aggressive or confrontational
❌ NEVER "Competitor X is wrong"
❌ NEVER attack category leaders
✅ Professional, empathetic, supportive
✅ Research-backed, people-focused
Risk: HIGH (HR community is small, reputation matters)

WHY THE DIFFERENCE:
- HR community is tight-knit (everyone knows everyone)
- HR leaders value relationships over aggressive positioning
- HR topics are sensitive (people, culture, layoffs)
- Attacking competitors = unprofessional (damages your brand)
- CHRO job changes = everyone moves to different companies
  → Today's competitor could be tomorrow's customer/partner
```

### **HR Tech Voice Guidelines:**

**TONE SPECTRUM (HR Tech):**

```
TOO AGGRESSIVE (Never Do This):
"Traditional performance reviews are BROKEN. Anyone still using them is hurting their team."
→ Judgmental, attacks current practices

TOO SOFT (Also Wrong):
"We think maybe employee engagement could possibly be important..."
→ Lacks confidence, not thought leadership

APPROPRIATE (Do This):
"Research shows traditional annual reviews have limitations. Here's what forward-thinking CHROs are trying instead."
→ Research-backed, helpful, not judgmental

IDEAL HR TECH VOICE:
- Confident but not arrogant
- Research-backed (cite studies, surveys)
- Empathetic (understand HR challenges)
- Helpful (provide frameworks, not just criticism)
- Inclusive (not everyone can afford premium tools)
- Professional (appropriate for CHRO audience)
```

### **Content Types for HR Tech Founders:**

**CONTENT MIX (HR Tech Series A):**

```
50% RESEARCH-BACKED INSIGHTS
- "Culture Amp's 2026 benchmark shows X"
- "New study on hybrid work effectiveness"
- "People analytics: What the data actually says"
Source: Industry research, academic studies, your product benchmarks
Length: 400-600 words
Frequency: 1-2× per week

30% PRACTICAL FRAMEWORKS
- "The 1-on-1 framework top managers use"
- "How to measure culture (beyond surveys)"
- "Performance review template for 100-person companies"
Source: Best practices, customer insights
Length: 500-700 words
Frequency: 1× per week

15% EMPATHETIC OBSERVATIONS
- "The CHRO challenge no one talks about"
- "Navigating layoffs with empathy [guide]"
- "What I learned from 100 employee exit interviews"
Source: Your experience, HR community insights
Length: 400-600 words
Frequency: 1× every 2 weeks

5% PERSONAL/VULNERABLE
- "The employee engagement program I launched (that failed)"
- "What I got wrong about performance management"
Source: Your honest journey
Length: 400-600 words
Frequency: Monthly or less (HR = professional, limit oversharing)
```

### **HR Tech Daily Content Workflow (3× per Week)**

**MONDAY: Research-Backed Insight (2 hours)**

```
08:00-09:00 | Find Research

HR TECH RESEARCH SOURCES:
□ SHRM (Society for HR Management) - industry gold standard
□ Josh Bersin research - HR thought leader
□ Culture Amp blog - engagement benchmarks
□ Lattice blog - performance management insights
□ Gartner HR research (if accessible)
□ Harvard Business Review - people management
□ Academic journals - organizational psychology

09:00-10:00 | Write Post

STRUCTURE:

**HOOK (Research Finding):**
"Culture Amp's 2026 benchmark report analyzed 500,000 employee surveys.
The #1 driver of retention isn't compensation. It's manager effectiveness.
By a margin of 3×."

**CONTEXT:**
This challenges conventional wisdom.
Most CHROs focus budget on:
- Competitive comp packages
- Benefits improvements
- Perks (ping pong, free lunch)

Meanwhile, the data shows:
- Manager quality = 3× more predictive of retention
- Direct manager relationship = #1 factor
- Yet: 60% of companies have no manager training budget

**FRAMEWORK:**
What top-performing companies do differently:
1. Manager selection (promote based on leadership, not tenure)
2. Manager training (quarterly coaching skills development)
3. Manager accountability (retention = performance metric)

**PRACTICAL APPLICATION:**
For small teams (50-200 employees):
- Start: Monthly manager training (2-hour sessions)
- Focus: 1 skill per quarter (giving feedback, career development, etc.)
- Measure: Manager effectiveness scores in engagement surveys

For mid-market (200-1000):
- Implement: Manager development program
- Budget: $500-1K per manager annually
- ROI: If retention improves 5%, savings = $X (calculate)

**CTA (Professional):**
"How does your company invest in manager development?
I'd love to learn from your approach."

NOT: "What do you think?" (too generic)
NOT: "Tag a bad manager" (unprofessional)
```

**WEDNESDAY: Practical Framework (2 hours)**

```
STRUCTURE:

**HOOK:**
"The 1-on-1 framework I've used with 50+ managers.
(Backed by research from MIT Sloan and Josh Bersin)"

**PROBLEM:**
Most 1-on-1s are status updates.
Manager asks: "What are you working on?"
Employee shares: "Project X, Project Y"
No growth. No connection. No development.

**FRAMEWORK: THE 3-TOPIC STRUCTURE**

Topic 1: IMMEDIATE (10 minutes)
- What's blocking you this week?
- Where do you need help?
- Any urgent concerns?

Topic 2: DEVELOPMENT (15 minutes)
- What skill do you want to build this quarter?
- What stretch opportunity interests you?
- How can I support your growth?

Topic 3: CONNECTION (5 minutes)
- How are you feeling about work?
- What's energizing you lately?
- Anything personal I should know about?

**WHY THIS WORKS:**
Research shows effective 1-on-1s have 3 elements:
1. Task support (immediate blockers)
2. Career development (future growth)
3. Relationship building (personal connection)

Most managers only do #1.
Top managers balance all 3.

**TEMPLATE:**
"Here's a simple template you can copy:
[Link to doc or image]"

**CTA:**
"What's your 1-on-1 structure?
Always looking to improve mine."

TONE: Helpful, not preachy
```

**FRIDAY: Empathetic Observation (1.5 hours)**

```
STRUCTURE:

**HOOK (Vulnerable Opening):**
"The CHRO challenge no one talks about:
You're responsible for culture. But you don't control it."

**SETUP:**
Every CHRO has felt this:
- CEO wants "better culture"
- Board asks about "employee engagement scores"
- But: You can't mandate culture

You can:
- Design programs
- Measure engagement
- Create policies

You can't:
- Control manager quality
- Force authentic relationships
- Manufacture belonging

**THE TENSION:**
This creates an impossible dynamic:
→ Accountable for outcomes
→ Limited control over inputs
→ Success depends on 100+ managers you don't directly manage

**WHAT HELPS:**
After talking to 30+ CHROs about this:

1. REFRAME YOUR ROLE
Not: "Owner of culture"
But: "Enabler of culture"

You don't create culture.
Managers create culture.
You enable them to do it well.

2. FOCUS ON SYSTEMS
- Manager selection (who gets promoted)
- Manager training (how we develop leaders)
- Manager accountability (metrics that matter)

3. MEASURE LEADING INDICATORS
Not just: Annual engagement scores
But: Monthly manager effectiveness scores

**CTA:**
"Fellow CHROs: How do you navigate this tension?
What's helped you?"

TONE: Vulnerable but professional
GOAL: Build community, not just thought leadership
```

### **HR Tech: What NEVER to Post**

```
❌ NEVER POST:

"Workday is terrible. Here's why:"
→ Attacks competitor (unprofessional)

"If your company still does annual reviews, you're behind"
→ Judgmental to audience (many still do this)

"The engagement survey results that shocked us [gossip]"
→ Violates employee privacy

"We just poached a great CHRO from [Company]"
→ Inappropriate, burns bridges

"Hot take: HR is mostly useless"
→ Self-destructive, alienates audience

"Check out this hilarious HR meme [generic meme]"
→ Low-value, undermines expertise

RULE FOR HR TECH:
If you wouldn't say it at SHRM Annual Conference, don't post it on LinkedIn.
```

---
