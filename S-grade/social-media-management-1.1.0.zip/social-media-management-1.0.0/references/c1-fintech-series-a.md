## **C1: Fintech @ Series A (Every Post Needs Legal Review)**

### **Your Reality Check:**

```
COMPANY PROFILE:
- Size: $2M-8M ARR, 20-100 employees
- Stage: Series A
- You: Founder
- Content goal: Build trust (not leads - trust comes first)
- Publishing: 1-2× per week (slower due to legal review)
- CRITICAL: Legal review mandatory for every single post
- Voice: Conservative, compliant, trustworthy
```

### **Why Fintech Content is HIGHEST RISK:**

```
SALES TECH:
✅ Aggressive positioning
✅ "Gong is wrong about X"
Risk: Low (lose followers)

HR TECH:
⚠️ Professional, no attacks
Risk: Medium (reputation)

FINTECH:
🔴 ULTRA-CONSERVATIVE MANDATORY
🔴 LEGAL REVIEW FOR EVERY POST
🔴 NEVER make unverified claims
🔴 NEVER attack competitors
🔴 NEVER share user data
Risk: EXTREME (regulatory fines, license revocation, criminal liability)

WHY:
- Financial regulations: RBI (India), SEC (US), FCA (UK)
- Financial advertising rules: Can't make unverified ROI claims
- Data privacy: Can't share user financial data (RBI compliance)
- Reputational risk: Finance = trust-driven (one mistake = brand death)
- Legal liability: Directors personally liable for violations
```

### **Fintech Content Guidelines (Non-Negotiable):**

```
✅ ALWAYS ALLOWED:

"RBI released new payment aggregator guidelines. Here's what fintech companies need to know:"
→ Regulatory updates (factual, helpful)

"3 compliance checklist items for Indian fintechs [2026 edition]"
→ Educational, compliance-focused

"How we achieved SOC 2 compliance in 12 months [timeline]"
→ Your journey (factual, no claims about others)

"CFO's guide to expense management compliance"
→ Educational, helpful

❌ NEVER ALLOWED:

"Traditional banking is broken. Here's why fintech is better."
→ Attacks incumbents (regulatory risk)

"Save 50% on payment fees with our solution"
→ Unverified ROI claim (unless proven and methodology disclosed)

"We're the fastest-growing fintech in India"
→ Superlative claim (unless third-party verified)

"Customer X saved ₹10L using our product"
→ Customer data (compliance violation without written permission)

"Why [Competitor] is overpriced"
→ Competitor attack (could trigger legal action)

CRITICAL RULE:
If you're not 100% certain it's compliant, get legal review.
In fintech, "better to ask forgiveness" DOES NOT APPLY.
```

### **Fintech Content Mix (Conservative):**

```
60% REGULATORY/COMPLIANCE UPDATES
- "New RBI guidelines for payment companies"
- "KYC requirements: What changed in 2026"
- "Data localization compliance checklist"
Source: Official sources only (RBI, NPCI, Ministry of Finance)
Tone: Factual, educational, helpful
Frequency: 1× per week (as regulations change)

25% EDUCATIONAL BEST PRACTICES
- "CFO's guide to corporate expense management"
- "How to evaluate payment aggregators [checklist]"
- "SOC 2 compliance: Step-by-step guide"
Source: Industry standards, your experience
Tone: Helpful, not sales-y
Frequency: 1× every 2 weeks

10% COMPANY UPDATES (Factual Only)
- "We achieved SOC 2 Type II certification"
- "Announcing: RBI Payment Aggregator license"
- "New integration: Zoho Books"
Source: Your company (factual announcements)
Tone: Professional, humble
Frequency: As milestones happen

5% THOUGHT LEADERSHIP (Extremely Careful)
- "The future of UPI payments in India [analysis]"
- "Cross-border payments: 2027 predictions"
Source: Industry trends (clearly labeled as opinion)
Tone: Measured, balanced, acknowledges uncertainty
Frequency: Monthly or less
```

### **Fintech Approval Workflow (Mandatory):**

```
EVERY POST FOLLOWS THIS PROCESS:

STEP 1: DRAFT (You or Writer)
- Write post
- Cite all sources
- Include disclaimers
Time: 1-2 hours

STEP 2: SELF-CHECK
□ Is this factual? (verifiable)
□ Do I cite sources? (RBI, official sources)
□ Am I making claims? (if yes, can I prove them?)
□ Am I mentioning competitors? (if yes, is it necessary?)
□ Am I sharing user data? (if yes, do I have written permission?)
□ Is there any regulatory risk? (when in doubt, YES)

STEP 3: LEGAL REVIEW (1-3 days)
- Send to legal counsel
- They review for:
  * Regulatory compliance
  * Financial advertising rules
  * Data privacy
  * Competitor mention risk
- They may:
  * Approve as-is
  * Request edits
  * Reject entirely

STEP 4: REVISE (If Needed)
- Incorporate legal feedback
- Re-submit for final approval

STEP 5: PUBLISH
- Only after legal sign-off
- Include all required disclaimers

TIMELINE:
- Simple post: 1-2 days (draft → legal → publish)
- Complex post: 3-5 days
- Controversial topic: May be rejected

COST:
- Legal counsel retainer: $5K-10K/month
- Per-post review: $200-500 (if not on retainer)
- Worth it: Avoiding ₹1 Cr fine or license revocation
```

### **Fintech Examples (Compliant vs Non-Compliant):**

```
TOPIC: Payment Processing Speeds

❌ NON-COMPLIANT:
"We process payments 10× faster than Razorpay.
Switch to us and save hours of processing time."

ISSUES:
- Unverified claim ("10× faster" - can you prove it?)
- Competitor attack (Razorpay could sue)
- Implied guarantee ("save hours" - what if customer doesn't?)

✅ COMPLIANT:
"Payment processing speeds vary by provider and use case.
In our testing with 100 transactions, average processing time was X seconds.
(Methodology: [link to documentation])"

WHY IT'S COMPLIANT:
- Factual (your own testing)
- Methodology disclosed
- No competitor attacks
- No guarantees

---

TOPIC: Cost Savings

❌ NON-COMPLIANT:
"Save 50% on payment fees!"

ISSUES:
- Unverified ROI claim
- No methodology
- Implies guarantee

✅ COMPLIANT:
"Payment fee structures vary by volume and use case.
Our pricing: X% per transaction + ₹Y fixed fee.
[Link to pricing page]
Compare options based on your transaction volume."

WHY IT'S COMPLIANT:
- Factual (your own pricing)
- No claims about competitors
- No ROI guarantee
- Helpful (empowers comparison)
```

---

# 📊 SECTION D: OPERATIONS TECH CONTENT WRITING

**When To Use This Section:**
- Your product: Retail execution, logistics, field force automation
- Your audience: Sales/Ops leaders at CPG/FMCG companies
- Your content angle: Distribution, retail, supply chain
- Voice: Industry-specific, B2B2B2C complexity
