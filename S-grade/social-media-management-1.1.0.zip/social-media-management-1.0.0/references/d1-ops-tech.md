## **D1: Operations Tech @ Series A (Niche Industry Focus)**

### **Your Reality Check:**

```
COMPANY PROFILE:
- Size: $1M-5M ARR, 15-60 employees
- Stage: Series A
- You: Founder (ex-CPG or tech)
- Content focus: India retail execution insights
- Publishing: 2-3× per week
- Audience: Small but highly engaged (CPG sales leaders)
```

### **Why Operations Tech Content is NICHE:**

```
SALES/HR/FINTECH:
- Broad audience (all B2B SaaS)
- Generic topics (sales, HR, finance)
- Large following potential (10K+ followers)

OPERATIONS TECH:
- Niche audience (CPG/FMCG/logistics)
- Specific topics (retail execution, distribution, field force)
- Smaller following (1K-3K) but HIGH engagement
- B2B2B2C complexity (You → CPG → Distributor → Retailer → Consumer)

ADVANTAGE OF NICHE:
✅ Less competition (few people write about retail execution)
✅ Higher engagement rate (exactly what audience needs)
✅ Easier to become THE expert
✅ Stronger community (CPG sales leaders all know each other)
✅ Higher intent leads (if they follow you, they're serious)
```

### **Operations Tech Content Topics:**

```
CORE TOPICS:

40% RETAIL EXECUTION INSIGHTS
- "State of general trade in India [Q4 2025 data]"
- "How kiranas are adapting to quick commerce"
- "Distribution coverage: North vs South India [analysis]"
Source: Your product data, industry reports, field observations
Audience: CPG sales heads, ops leaders

30% FIELD FORCE BEST PRACTICES
- "The beat planning framework that increased coverage by 20%"
- "How top field reps use mobile apps [case study]"
- "Offline-first: Why it matters for rural distribution"
Source: Customer success stories, your product
Audience: Field force managers, ops leaders

20% CPG INDUSTRY TRENDS
- "Quick commerce impact on FMCG distribution [2026]"
- "D2C brands: Distribution lessons for CPG"
- "How HUL/ITC are changing go-to-market"
Source: Industry news, earnings calls, your analysis
Audience: CPG strategy, business leaders

10% TECHNOLOGY IN RETAIL/LOGISTICS
- "How AI is changing retail audits"
- "Image recognition for planogram compliance"
- "Route optimization: Tech vs manual planning"
Source: Your product innovation, industry tech trends
Audience: Tech-forward ops leaders
```

---

# 🔄 CROSS-CUTTING: UNIVERSAL FRAMEWORKS
