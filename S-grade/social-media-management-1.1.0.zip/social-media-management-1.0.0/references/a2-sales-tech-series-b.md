## **A2: Sales Tech @ Series B (Team Content, Professional Voice)**

### **Your Reality Check:**

```
COMPANY PROFILE:
- Size: $10M-40M ARR, 150-500 employees
- Stage: Series B
- You: VP Marketing or Content Lead
- Team: 1-2 content writers + designer
- Content goal: Thought leadership + brand building
- Publishing: 5-7× per week (company account)
- Approval: Manager/CEO review for company posts
- Budget: $3K-10K/month for content
```

### **Why Series B Content is Different:**

```
SERIES A CONTENT:
- Founder voice (personal, authentic)
- Scrappy (founder writes everything)
- Tactical (helping peers)
- Goal: Build personal + company brand

SERIES B CONTENT:
- Brand voice (professional, consistent)
- Team effort (writers, designers, approval)
- Strategic (thought leadership)
- Goal: Category positioning

NEW CHALLENGES:
- Maintain authenticity while scaling
- Multiple stakeholders (CEO, Sales, Product)
- Balancing founder voice vs company voice
- Higher quality bar (professional design expected)
```

### **Series B Sales Tech: Content Team Structure**

```
TEAM ROLES:

CONTENT LEAD (You):
- Strategy (what topics, what angles)
- Approval (final say on all posts)
- Stakeholder management (CEO, Sales, Product)
- Metrics (track engagement, leads, brand impact)
Time: 15-20 hours/week

CONTENT WRITER (1-2 FTE):
- Research (find data, customer stories)
- Drafting (write posts, threads, articles)
- Editing (polish, optimize)
- SEO (keywords, hashtags)
Time: 30-40 hours/week

DESIGNER (Part-time or contractor):
- Carousels (LinkedIn carousels for complex topics)
- Infographics (data visualization)
- Branded templates (consistent look)
Time: 10-15 hours/week

FOUNDER/CEO (Guest):
- 1-2 posts per week under their name
- High-level strategic takes
- Company announcements
Time: 2-3 hours/week (ghost-written, they edit)

TOOLS & BUDGET ($3K-10K/month):
□ Design: Canva Pro ($13/mo) or Figma ($12/user/mo)
□ Scheduling: Taplio ($39/mo) or Shield ($12/mo)
□ Analytics: Shield Analytics ($12/mo)
□ Carousel creation: Canva or custom designer ($500-2K/mo)
□ Stock photos: Unsplash (free) or Shutterstock ($29-199/mo)
□ Writing tools: Grammarly Premium ($12/mo), Hemingway (free)
```

### **Series B Approval Workflow:**

```
STANDARD POST (Product update, tactical tip):
Writer → Content Lead → Publish
Timeline: Same day

STRATEGIC POST (Contrarian take, competitor analysis):
Writer → Content Lead → VP Marketing → Publish
Timeline: 1-2 days

SENSITIVE POST (Pricing, roadmap, executive POV):
Writer → Content Lead → VP Marketing → CEO → Legal (if needed) → Publish
Timeline: 3-5 days

FOUNDER GHOST-WRITE:
Writer draft → Content Lead edit → Founder review/edit → Publish (under founder name)
Timeline: 2-3 days
CRITICAL: Founder has final say (it's their voice)

APPROVAL DECISION TREE:

Question: Is this factual/tactical?
YES → Standard approval (Content Lead)
NO → Continue...

Question: Does this challenge competitors/industry?
YES → Strategic approval (VP Marketing)
NO → Continue...

Question: Does this touch pricing/strategy/roadmap?
YES → Sensitive approval (CEO)
NO → Standard approval

Question: Could this create legal risk?
YES → Legal review (add 3-5 days)
NO → Proceed with appropriate approval tier
```

### **Series B Weekly Content Calendar:**

```
MONDAY:
□ 09:00 | Company post: Data-driven insight
  Topic: "We analyzed 100K sales calls in Q4. Here's what changed."
  Writer: Staff writer
  Format: LinkedIn post (400-500 words)
  Visual: Data viz (bar chart or line graph)
  Approval: Content Lead
  
□ 12:00 | Founder post: Weekend reflection
  Topic: "5 sales trends I'm watching in 2026"
  Writer: Ghost-written (founder edits heavily)
  Format: LinkedIn post (300-400 words)
  Approval: Founder (final say)

TUESDAY:
□ 09:00 | Company post: Tactical framework (carousel)
  Topic: "The objection handling framework we teach customers"
  Format: LinkedIn carousel (8-10 slides)
  Designer: Create branded template
  Writer: Framework content
  Approval: Content Lead → VP Marketing (if new framework)
  
□ 14:00 | Customer story (LinkedIn article)
  Topic: "How [Customer] scaled from $5M to $20M ARR"
  Format: Long-form article (800-1200 words)
  Writer: Interview customer, write case study
  Approval: Customer approval + Content Lead

WEDNESDAY:
□ 09:00 | Company post: Industry commentary
  Topic: "Gong's Series D: What it means for SMB sales tech"
  Writer: Research news, add perspective
  Format: Analysis (400-500 words)
  Approval: Content Lead → VP Marketing (competitive topic)
  
□ 16:00 | Founder post: Personal insight
  Topic: "The sales hire that changed our trajectory"
  Writer: Ghost-written from founder interview
  Format: Story (400-500 words)
  Approval: Founder

THURSDAY:
□ 09:00 | Company post: Quick win
  Topic: "3 LinkedIn prospecting tips from our SDR team"
  Format: Short tips (250-350 words)
  Writer: Interview SDR manager
  Approval: Content Lead
  
□ 12:00 | Product Marketing: Feature announcement (if launching)
  Writer: PMM writes, Content Lead edits
  Format: Feature post + carousel
  Approval: PMM → Content Lead → VP Marketing

FRIDAY:
□ 09:00 | Founder post: Weekly learnings
  Topic: "3 things I learned this week about sales coaching"
  Writer: Founder writes this one (authentic)
  Format: Quick reflection (200-300 words)
  Approval: None (founder direct)
  
□ 14:00 | Community engagement post
  Topic: "Friday question: What's your biggest sales challenge right now?"
  Format: Simple question + comment engagement
  Goal: Build community, spark discussion
  Approval: Content Lead

WEEKEND (Schedule for Monday):
□ SAT | Batch write next week's drafts
□ SUN | Review analytics from previous week
```

### **Series B: Data-Driven Content Strategy**

```
QUARTERLY CONTENT INITIATIVES:

Q1: ORIGINAL RESEARCH REPORT
"The State of SMB Sales 2026"

Production:
Week 1-2: Survey design
- 500+ sales leaders
- 20 questions (multiple choice + open-ended)
- Incentive: $50 Amazon gift card (100 recipients)
- Platform: Typeform ($35/mo)

Week 3-4: Data collection
- Email outreach (to customer list)
- LinkedIn post (survey link)
- Partner distribution (Pavilion, Sales Hacker)
- Goal: 500+ responses

Week 5-6: Analysis
- Data analyst: Clean data, find insights
- Writer: Identify 5-7 key findings
- Designer: Create data visualizations

Week 7-8: Content production
- Full report (30-40 pages PDF)
- Summary blog post (1,000 words)
- LinkedIn carousel series (3-4 carousels)
- Webinar presentation

Week 9-12: Distribution & amplification
- Publish report (gated, capture emails)
- 4-week LinkedIn series (one finding per week)
- Guest posts on Sales Hacker, Pavilion
- PR outreach (TechCrunch, SaaStr)
- Webinar (present findings, Q&A)

Budget:
- Survey incentives: $5,000
- Design (report): $2,000-5,000
- Promotion: $3,000-5,000
- Total: $10,000-15,000

Impact:
- 1,000-2,000 report downloads
- 100-200 SQLs
- Media coverage (TechCrunch, SaaStr mention)
- Sales enablement (differentiation vs competitors)
- Thought leadership (cited by industry)

Q2-Q4: Additional initiatives
- Q2: Customer benchmarking report
- Q3: Competitive landscape analysis
- Q4: 2027 predictions + trends
```

---
