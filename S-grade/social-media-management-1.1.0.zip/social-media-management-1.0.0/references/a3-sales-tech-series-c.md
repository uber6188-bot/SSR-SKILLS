## **A3: Sales Tech @ Series C+ (Category Ownership)**

### **Your Reality Check:**

```
COMPANY PROFILE:
- Size: $50M+ ARR, 500+ employees
- Stage: Series C/D or preparing IPO
- You: Director of Content / Head of Thought Leadership
- Team: 3-5 FTE (writers, designers, analysts, video)
- Content: Category-defining thought leadership
- Budget: $20K-50K/month
- Goal: Own the conversation (like Gong Labs, Pavilion, SaaStr)
```

### **Series C+ Content = Category Ownership**

```
SERIES A/B GOALS:
- Generate leads
- Build brand awareness
- Establish thought leadership

SERIES C+ GOAL:
- OWN the conversation in your category
- Be THE source that media/analysts/customers cite
- Influence industry direction
- Recruiting magnet (top talent reads your content)

EXAMPLES OF CATEGORY OWNERSHIP:
- Gong Labs (conversation intelligence insights)
- Pavilion (GTM community + content)
- SaaStr (B2B SaaS conferences + content)
- First Round Review (startup advice)
- a16z blog (startup/tech trends)

YOUR CONTENT BECOMES:
- Industry-defining (sets agenda)
- Media-cited (journalists reference you)
- Board-level reading (not just practitioners)
- Recruiting tool ("I read your blog" in interviews)
```

### **Series C+ Content Team:**

```
ORGANIZATIONAL STRUCTURE:

DIRECTOR OF CONTENT (You):
- Strategy: What makes us category leaders?
- Partnerships: Media, analysts, industry orgs
- Executive alignment: CEO/CMO/Board
- Budget management: $20K-50K/month
- Metrics: Brand awareness, category leadership signals

MANAGING EDITOR:
- Editorial calendar: Plan 3 months ahead
- Quality control: Everything excellent or doesn't ship
- Writer management: Assign, edit, coach
- Process: Systems that scale

SENIOR CONTENT WRITER (2-3):
- Original research: Lead quarterly reports
- Thought leadership: Strategic analysis
- Specialization: Each owns topic area
  * Writer 1: Sales methodology, frameworks
  * Writer 2: Data/research, benchmarks
  * Writer 3: Industry trends, competitive analysis

DATA ANALYST:
- Research design: Survey questions, methodology
- Data analysis: Find insights in product data
- Visualization: Charts, graphs, dashboards
- Reporting: Present findings to exec team

SENIOR DESIGNER:
- Brand-level quality: Every asset premium
- Data visualization: Make complex data clear
- Templates: Scalable, consistent design system
- Video production: Motion graphics for social

VIDEO PRODUCER (Optional but recommended):
- Short-form: 60-90 second LinkedIn videos
- Webinars: Professional production quality
- Podcast: If you have one
- YouTube: Thought leadership channel

CONTENT OPERATIONS / COORDINATOR:
- Scheduling: Manage content calendar
- Distribution: LinkedIn, Twitter, email, etc.
- Analytics: Track performance across channels
- Coordination: Keep everyone aligned

TOOLS & BUDGET ($20K-50K/month):

TIER 1: Publishing Infrastructure ($1K-3K/month)
□ CMS: WordPress, Webflow ($50-200/mo)
□ Email: HubSpot, Marketo ($1K-2K/mo for enterprise)
□ Scheduling: Hootsuite, Sprout Social ($200-500/mo)
□ Analytics: Google Analytics + custom dashboards

TIER 2: Research & Data ($3K-10K/month)
□ Survey platform: Qualtrics ($200-500/mo)
□ Research incentives: $2K-5K per study
□ Data visualization: Tableau ($70/user/mo)
□ Industry subscriptions: Gartner, Forrester ($3K-5K/mo)

TIER 3: Content Production ($5K-15K/month)
□ Team salaries: $15K-30K/month (3-5 FTE fully loaded)
□ Freelancers: Subject matter experts ($500-2K per piece)
□ Design tools: Adobe Creative Cloud ($55/mo/user)
□ Stock assets: Photos, videos ($200-500/mo)

TIER 4: Distribution & Amplification ($5K-15K/month)
□ Paid social: LinkedIn ads ($3K-8K/mo)
□ Sponsorships: Industry newsletters ($2K-5K/placement)
□ PR agency: If needed ($5K-15K/mo retainer)
□ Events: Speaking slots, sponsored content

TIER 5: Video & Multimedia ($5K-10K/month if doing video)
□ Video production: Equipment, editing software
□ Video editor: Part-time or contractor
□ Podcast production: If applicable
□ YouTube optimization: Thumbnails, SEO
```

### **Series C+ Content Strategy: Flagship Initiatives**

```
ANNUAL CONTENT FLAGSHIP: "THE STATE OF B2B SALES [2026]"

This is your category-defining research report.

SCOPE:
- Survey: 2,000-5,000 sales leaders
- Product data: Analyze 10M+ sales conversations
- Academic partnership: Validate with university researchers
- Executive interviews: 50 CROs/VPs Sales
- Timeline: 4-6 months production
- Budget: $40K-80K

METHODOLOGY:
Month 1-2: Research design
- Survey questions (partner with Qualtrics)
- IRB approval (if partnering with university)
- Sample selection (ensure representative)
- Pre-test survey (100 respondents, iterate)

Month 3-4: Data collection
- Survey distribution:
  * Email to 50K sales leaders (bought list)
  * LinkedIn campaign ($10K ad spend)
  * Partner promotion (Pavilion, Sales Hacker, SaaStr)
  * Customer outreach (guaranteed responses)
- Goal: 2,000-5,000 complete responses
- Incentive: $100 Amazon gift card (200 winners)

Month 5: Analysis
- Data cleaning: Remove incomplete/invalid
- Statistical analysis: Regression, correlation, segmentation
- Product data integration: Combine survey + product insights
- Visualization: 30-50 charts/graphs
- Insights identification: What's surprising? What matters?

Month 6: Production
- Report writing: 60-80 pages
- Executive summary: 4-page overview
- Design: Premium quality (looks like Gartner/Forrester)
- Infographics: Shareable data visualizations
- Landing page: Report download (gated)

POST-LAUNCH AMPLIFICATION (3 months):

Week 1: Launch
- Press release: Wire services
- Media outreach: TechCrunch, WSJ, Forbes
- LinkedIn campaign: Promote to 100K sales leaders
- Customer email: Send to all customers
- Webinar: Present findings (500+ registrants)

Week 2-4: Content series
- LinkedIn: 12 posts (one finding per post)
- Blog: 4 deep-dive articles
- Podcast: 3 episodes discussing findings
- Guest posts: Publish on Pavilion, Sales Hacker, etc.

Month 2-3: Speaking circuit
- Conferences: Present at SaaStr, Pavilion Summit, Sales 3.0
- Webinars: Partner with complementary tools
- Podcasts: Guest on top 10 sales podcasts
- Customer events: Present at your user conference

IMPACT METRICS:

REACH:
- 10,000+ report downloads
- 500,000+ social impressions
- 50+ media mentions
- 20+ conference/podcast presentations

BUSINESS:
- 300-500 SQLs directly attributed
- $2M-5M pipeline influenced
- Sales enablement (differentiation in 100+ deals)
- Recruiting (mentioned in 50+ candidate interviews)

CATEGORY LEADERSHIP:
- Cited by Gartner/Forrester in their reports
- Referenced in competitor earnings calls
- Academic papers cite your research
- Industry orgs invite you to present
- Media calls YOU for expert commentary

ROI:
- Cost: $60K-100K (full production + promotion)
- Pipeline influenced: $2M-5M
- ROI: 20-50× (if even 1-2% of pipeline closes)
```

### **Series C+ Content Distribution: Media Company Level**

```
OWNED CHANNELS:

BLOG:
- Frequency: 2-3× per week
- Topics: Thought leadership, research, frameworks
- SEO: Optimized for category keywords
- Goal: 50K-100K monthly visitors

LINKEDIN (Company):
- Frequency: 5-7× per week
- Mix: Data insights, frameworks, company updates
- Followers: 50K-150K+
- Engagement: 2-5% (very high for company page)

LINKEDIN (Founder/Execs):
- CEO: 2-3× per week (high-level strategy)
- CMO: 1-2× per week (marketing insights)
- CRO: 1-2× per week (sales insights)
- Followers: 10K-50K each
- Engagement: 5-10% (personal accounts higher)

YOUTUBE:
- Frequency: 1-2× per week
- Content: Research summaries, webinar recordings, interviews
- Subscribers: 5K-20K
- Goal: Thought leadership, not viral videos

PODCAST:
- Frequency: Weekly
- Format: Interview sales leaders (30-45 min)
- Distribution: Apple, Spotify, YouTube
- Downloads: 1K-5K per episode

EMAIL NEWSLETTER:
- Frequency: Weekly
- Subscribers: 20K-60K
- Open rate: 25-35%
- Content: Curated insights + original commentary

EARNED CHANNELS:

MEDIA COVERAGE:
- TechCrunch, Forbes, WSJ (2-4× per year)
- Industry pubs: Sales Hacker, SaaStr, Pavilion (monthly)
- Podcasts: Top 20 sales podcasts (quarterly)
- Position: Expert source (journalists quote you)

SPEAKING:
- Tier 1 conferences: SaaStr, Pavilion Summit, Sales 3.0 (keynote)
- Tier 2 conferences: Regional sales events (breakout sessions)
- Customer events: Your user conference (opening keynote)
- Virtual: 10-20 webinars per year

ANALYST RELATIONS:
- Gartner: Briefings 2× per year
- Forrester: Wave participation
- Pavilion: Community partnership
- Josh Bersin: If HR Tech adjacency

ACADEMIC:
- University partnerships: Research collaborations
- Journal publications: Peer-reviewed if possible
- Guest lectures: MBA programs (sales/marketing)
- Thesis advising: If relevant

PAID CHANNELS:

SPONSORED CONTENT:
- Industry newsletters: Pavilion, Sales Hacker ($5K-15K per placement)
- LinkedIn ads: Promote flagship research ($10K-20K per campaign)
- Conference sponsorships: SaaStr, Pavilion ($20K-50K per event)

PARTNER CHANNELS:
- Integration partners: Salesforce, HubSpot, Outreach (co-marketing)
- Community partners: Pavilion, Revenue Collective (content swaps)
- Analyst firms: Gartner, Forrester (sponsor research)
- Academic: Universities (research partnerships)
```

---

# 📊 SECTION B: HR TECH CONTENT WRITING

**When To Use This Section:**
- Your product: HRIS, employee engagement, performance, recruiting
- Your audience: HR leaders, CHROs, People Ops, Talent teams
- Your content angle: Employee experience, people analytics, culture
- Voice: Professional, empathetic, research-backed (NEVER aggressive)

---
