## **Worked Examples: Multi-Dimensional Scenarios**

### **Example 1: Sales Tech Founder, Series A, Aggressive Post**

```
SCENARIO:
- Company: AI sales coaching, $3M ARR, 30 employees
- You: Co-founder & CEO
- Goal: Challenge Gong's methodology (contrarian take)
- Platform: LinkedIn
- Approval: None (founder autonomy)

CONTENT APPROACH:

TOPIC: "Gong's data on discovery calls is misleading. Here's why:"

STEP 1: GATHER DATA (Your Product)
- Export: 50,000 sales calls from your product
- Analyze: Average discovery call length
- Finding: Your data shows 25 minutes (vs Gong's 38 minutes)
- Hypothesis: Different ICP (SMB vs enterprise)

STEP 2: WRITE HOOK (Aggressive but Credible)
"Gong says the average discovery call is 38 minutes.
We analyzed 50,000 calls and found 25 minutes.

Here's what Gong missed:"

STEP 3: BUILD CASE (Data-Driven)
The difference:
- Gong's data: Skews enterprise (longer, more complex sales)
- Our data: Focuses SMB B2B SaaS (faster cycles)
- SMB discovery: 15-25 minutes (more efficient)
- Enterprise discovery: 35-45 minutes (more stakeholders)

STEP 4: NUANCE (Important)
"Am I saying Gong is wrong? No.
Am I saying their data doesn't apply to SMB? Yes.

If you're selling to SMB, optimize for 20-minute discovery.
If you're enterprise, 35-40 minutes is right."

STEP 5: PUBLISH + AMPLIFY
- LinkedIn: Tuesday 9 AM EST
- First comment: Link to methodology
- Tag: @mention Gong (they might engage)
- Monitor: Reply to all comments within 1 hour

RESULT:
- Engagement: 2-3× normal (controversial = engagement)
- Comments: Mix of agreement + Gong defenders (debate = algorithm boost)
- Leads: 15-20 inbound "I agree with your SMB POV"
- Gong might respond (if they do, be respectful)

RISK ASSESSMENT:
- Risk level: Medium (challenging industry leader)
- Mitigation: Data-backed, nuanced, respectful
- Worst case: Gong ignores or politely disagrees
- Best case: Healthy debate, massive reach
```

### **Example 2: HR Tech VP, Series B, Sensitive Topic (Layoffs)**

```
SCENARIO:
- Company: Employee engagement platform, $20M ARR
- You: VP Marketing
- Context: Your company just laid off 15% of staff
- Goal: Address layoffs professionally
- Constraint: Can't post until official announcement

TIMELINE:

DAY 1 (Layoff Day):
❌ Don't post anything on LinkedIn yet
✅ Focus on: Supporting impacted employees internally
✅ Wait for: Official company communication

DAY 2-3 (After Official Announcement):
✅ Now you can post (company has communicated)

CONTENT APPROACH:

STEP 1: CHECK WITH LEADERSHIP
Before writing:
□ Does CEO/CHRO want me to post?
□ What's the approved messaging?
□ Any topics to avoid?
□ Legal review needed?

STEP 2: WRITE POST (Empathetic, Honest)

HOOK:
"We made difficult decisions this week.
As someone who had to deliver hard news to people I deeply respect,
I want to share what I learned about navigating reductions with empathy."

BODY:
What mattered most:
1. Clarity (people deserve straightforward answers, not corporate speak)
2. Dignity (generous severance, extended benefits, placement support)
3. Support (for those leaving AND those staying)

For those impacted:
- I'm happy to provide LinkedIn recommendations
- I'll make intros where I can
- You deserved better timing, and I'm sorry

For the team staying:
- We're committed to getting this right
- Your questions deserve honest answers
- We'll rebuild trust through actions

CTA:
"If you've navigated this as a leader, I'd appreciate your guidance.
And if you're hiring for [roles], several incredible people are looking."

STEP 3: LEGAL REVIEW
□ Send to legal counsel
□ Check: Any liability concerns?
□ Confirm: Severance terms not disclosed (confidential)
□ Ensure: No promises made that company can't keep

STEP 4: PUBLISH + MONITOR
- Time: Not Friday evening (shows lack of care)
- Better: Tuesday-Wednesday (thoughtful timing)
- Monitor: Comments (many will be supportive, some critical)
- Respond: Acknowledge, don't defend

APPROVAL CHAIN:
Draft → Legal → VP Marketing → CHRO → CEO → Publish
Timeline: 3-5 days

RESULT:
- Humanizes difficult decision
- Shows empathy + accountability
- Helps impacted employees (visibility for job search)
- Maintains professional reputation
```

### **Example 3: Fintech Founder, Series A, Regulatory Update Post**

```
SCENARIO:
- Company: Payment aggregator, $4M ARR, 40 employees
- You: Founder & CEO
- Context: RBI just released new PA guidelines
- Goal: Educate fintech community
- Constraint: Legal review mandatory

CONTENT APPROACH:

STEP 1: READ OFFICIAL SOURCE
- RBI circular: Download PDF, read thoroughly
- Identify: 5-7 key changes
- Clarify: What's new vs what's unchanged
- Consult: Legal counsel for interpretation

STEP 2: DRAFT POST (Conservative, Educational)

HOOK:
"RBI released updated Payment Aggregator guidelines yesterday.
Here's what fintech companies need to know:"

BODY:
Key changes (effective April 1, 2026):

1. KYC Requirements Strengthened
- Previous: Basic KYC for merchants
- New: Enhanced due diligence for high-risk categories
- Action: Review your merchant onboarding process

2. Data Localization Timeline
- Previous: "As soon as possible"
- New: Mandatory by June 30, 2026
- Action: If you're not compliant, start now (6-month timeline)

3. Reporting Requirements
- Previous: Quarterly
- New: Monthly submission to RBI
- Action: Update your compliance calendar

4. Net-Worth Requirements
- No change: Still ₹15 crore minimum
- Clarification: Must be maintained at all times

NOT CHANGED (Important):
- License renewal: Still 3 years
- Merchant agreement requirements: Unchanged
- Settlement timelines: Remain T+1

DISCLAIMER:
"This is for informational purposes only and does not constitute legal advice.
Always consult qualified legal counsel for your specific situation."

STEP 3: LEGAL REVIEW (1-2 days)
Send to legal counsel:
□ Check factual accuracy
□ Verify no overstatement
□ Confirm disclaimer is appropriate
□ Ensure no competitive mentions

STEP 4: PUBLISH + DISTRIBUTE
- LinkedIn: Tuesday 10 AM IST (India market)
- First comment: Link to official RBI circular
- Distribution: Share in IAMAI fintech group
- Email: Send to customer list (value-add)

RESULT:
- Positions you as: Helpful expert (not sales-y)
- Builds trust: Fintech community appreciates clarity
- Leads: "We need help with compliance" inquiries
- Risk: Zero (factual, legal-reviewed, helpful)

CONTRAST WITH WRONG APPROACH:

❌ DON'T WRITE:
"RBI's new rules will kill most payment companies.
Here's why we're better positioned than our competitors."

WHY IT'S WRONG:
- Fear-mongering (unprofessional)
- Competitor mention (unnecessary)
- Could trigger regulatory scrutiny
```

---
