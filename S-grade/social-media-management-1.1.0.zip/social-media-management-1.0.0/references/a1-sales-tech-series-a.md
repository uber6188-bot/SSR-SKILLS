## **A1: Sales Tech @ Series A (Founder Voice, Aggressive Allowed)**

### **Your Reality Check:**

```
COMPANY PROFILE:
- Size: $1M-10M ARR, 10-100 employees
- Stage: Series A
- You: Founder or early marketing hire
- Content goal: Build thought leadership + leads
- Publishing: 3-5× per week (LinkedIn primary)
- Approval: None (founder autonomy)
- Time: 5-8 hours/week total
```

### **The Sales Tech Content Philosophy:**

**Why Sales Leaders Engage with Content:**

```
SALES LEADERS DON'T ENGAGE WITH:
❌ Generic motivational quotes
❌ Theory without data
❌ Long-winded essays (no time)
❌ Humble bragging ("We just closed...")

SALES LEADERS ENGAGE WITH:
✅ Data-driven insights ("Analyzed 10K calls, here's what top reps do")
✅ Tactical frameworks (copy-paste into your process)
✅ Contrarian takes ("Everyone is wrong about cold calling")
✅ Competitive intelligence ("What Gong doesn't tell you")
✅ ROI calculations ("This tactic = 23% more meetings")
```

### **Sales Tech Voice Guidelines:**

**AGGRESSIVENESS SPECTRUM (Sales Tech):**

```
TOO TIMID (Don't Do This):
"We think conversation intelligence might be helpful for some teams..."

APPROPRIATELY CONFIDENT (Do This):
"Gong analyzed 1M calls. We analyzed 2M. Here's what they missed."

TOO AGGRESSIVE (Even for Sales Tech):
"Gong is garbage. Their data is fake. We're 100× better."

SWEET SPOT:
- Confident, data-backed assertions
- Respectful but contrarian takes
- Challenge category leaders on methodology
- But: Never personal attacks, never unverified claims
```

### **Content Types for Sales Tech Founders:**

**CONTENT MIX (Sales Tech Series A):**

```
40% DATA-DRIVEN INSIGHTS
- "We analyzed X sales calls, here's what we found"
- "The data says [surprising insight]"
- Source: Your product data, public research (Gong, Pavilion)
- Length: 300-500 words
- Frequency: 2× per week

30% TACTICAL FRAMEWORKS
- "The 3-question discovery framework"
- "How to handle pricing objections [step-by-step]"
- Source: Your experience, customer wins
- Length: 400-600 words
- Frequency: 1-2× per week

20% CONTRARIAN TAKES
- "Why everyone is wrong about [X]"
- "Gong says [X], but the data shows [Y]"
- Source: Your unique perspective, counter-research
- Length: 200-400 words
- Frequency: 1× per week

10% PERSONAL/BEHIND-THE-SCENES
- "How we lost a $50K deal (and what I learned)"
- "The sales hire that changed our trajectory"
- Source: Your journey
- Length: 300-500 words
- Frequency: 1× every 2 weeks
```

### **Series A Sales Tech: Daily Content Workflow**

**MONDAY: Data-Driven Insight (1.5 hours)**

```
09:00-09:30 | Find Data

SALES TECH DATA SOURCES:
□ Your product: Export anonymized metrics
  Example: "Average discovery call = 32 minutes in our data"
  
□ Public research:
  - Gong Labs reports (free)
  - Pavilion benchmarks (if member)
  - Public earnings calls (check Salesforce, ZoomInfo)
  
□ Customer interviews:
  - "What was your close rate before/after using us?"
  - Turn into: "Customer X increased close rate 23%"

09:30-10:30 | Write Post

STRUCTURE:

**HOOK (First 2 lines):**
"We analyzed 50,000 sales calls from SMB B2B SaaS companies.
The average discovery call is 32 minutes. But top performers? 19 minutes."

**BUILD (3-5 paragraphs):**
Why this matters:
- Shorter calls = more qualified prospects
- Top reps ask fewer questions (but better ones)
- They don't "interrogate," they diagnose

What we found:
1. Average rep asks 18 questions in discovery
2. Top rep asks 9 questions (but they're open-ended)
3. Top rep listens 67% of the time (vs 42% for average)

**PAYOFF (1-2 paragraphs):**
The 3 questions top reps always ask:
1. "Walk me through your current process for [X]"
2. "What happens if you don't solve this in the next 90 days?"
3. "Who else is impacted by this problem?"

**CTA:**
"What's your go-to discovery question?"

10:30-11:00 | Edit & Publish

SALES TECH EDITING CHECKLIST:
□ Cut 20-30% of words (brevity = respect for time)
□ Verify: Every claim has data/source
□ Add: Numbers, percentages, specifics
□ Remove: Fluff, qualifiers ("I think," "maybe")
□ Check: Does this make sales leaders smarter?

PUBLISH:
- Time: 9 AM EST / 6 AM PST (catch US East + West)
- If India: 9 AM IST (catch Indian B2B audience)
- Platform: LinkedIn primary, Twitter thread secondary
```

**TUESDAY: Tactical Framework (1.5 hours)**

```
STRUCTURE:

**HOOK:**
"The pricing objection framework every SDR should memorize:
(Learned this from watching 1,000+ pricing conversations)"

**FRAMEWORK:**
When they say: "That's too expensive"

DON'T say:
❌ "We're actually quite affordable"
❌ "Let me talk to my manager about a discount"
❌ "What's your budget?"

DO say (3-step framework):

Step 1: REFRAME
"Expensive compared to what? [competitor]?"
→ Forces them to make comparison explicit

Step 2: QUANTIFY THEIR PROBLEM
"Walk me through what this problem costs you today.
 How many hours per week? What's your team's loaded cost?"
→ Now you have their ROI baseline

Step 3: CONTRAST VALUE
"So you're spending $50K/year in time right now.
 Our solution is $15K/year and eliminates 90% of that.
 That's a $35K gain. Does that math work?"
→ Reframe from cost to investment

**EXAMPLE:**
[Insert short dialogue showing this in action]

**CTA:**
"Try this next time you hear 'too expensive.'
 Let me know how it goes."

LENGTH: 400-600 words
TIME: 1.5 hours (research + write + edit)
```

**WEDNESDAY: Contrarian Take (1 hour)**

```
STRUCTURE:

**HOOK (Provocative):**
"Unpopular opinion: Gong is making your sales team WORSE.
(And I have data to prove it)"

**SETUP:**
Everyone thinks conversation intelligence = better sales.
More data = better coaching = more wins.

But here's what we're seeing:

**THE CONTRARIAN INSIGHT:**
When sales teams get Gong:
- Month 1-3: 15% improvement (reps more aware)
- Month 4-6: Flatline (back to baseline)
- Month 7+: Often 5-10% decline

Why?
1. Analysis paralysis (too much data, not enough action)
2. Reps game the metrics (talk more to hit "talk time" goals)
3. Managers overwhelmed (100 dashboards, 0 time to coach)

**THE ALTERNATIVE VIEW:**
Conversation intelligence isn't the problem.
How you USE it is.

Best teams:
- Track 3 metrics max (not 30)
- Focus on ONE skill per quarter
- Coach live (not post-call reviews)

**NUANCE (Important for Aggressive Takes):**
"Am I saying Gong is bad? No.
Am I saying most teams use it wrong? Yes."

**CTA:**
"Using conversation intelligence? What's working for you?"

RISK LEVEL: Medium-High
APPROVAL: Founder only (don't do this as employee)
WHEN: Only if you have data + alternative
```

**THURSDAY: Quick Tip (30 minutes)**

```
STRUCTURE:

**HOOK:**
"The 2-minute LinkedIn outreach hack that 3× my reply rate:"

**THE HACK:**
Before sending connection request:
1. Comment on their post (genuine, add value)
2. Wait 24 hours
3. THEN send personalized connection request

Why it works:
- They remember you (positive association)
- Not cold anymore (warm intro via comment)
- Shows you did research (not spray-and-pray)

**EXAMPLE:**
[Screenshot or dialogue]

**CTA:**
"Try it. Let me know your reply rate."

LENGTH: 150-250 words
TIME: 30 minutes
FREQUENCY: 1× per week (easy win days)
```

**FRIDAY: Customer Win / Case Study (1 hour)**

```
STRUCTURE:

**HOOK:**
"How a 10-person startup beat Salesforce for a $100K deal:
(A masterclass in positioning)"

**SETUP:**
Our customer: Small sales tech startup
Competitor: Salesforce (800 lb gorilla)
Deal size: $100K annual

How they won:

**THE STORY:**
Step 1: They DIDN'T compete on features
→ Salesforce has 10× more features
→ That's a losing battle

Step 2: They reframed the decision
→ "You have 15 sales reps. Salesforce is built for 500+ rep teams.
   You'll pay for complexity you don't need."

Step 3: They offered implementation in 1 week
→ Salesforce: 3-month implementation
→ Them: Live in 1 week

Step 4: They made it founder-to-founder
→ CEO jumped on call (rare for Salesforce)
→ Committed to being "partner, not vendor"

**THE WIN:**
Customer chose them despite:
- Salesforce brand
- Salesforce features
- Salesforce pricing power

Why?
- Speed to value
- Right-sized solution
- Personal relationship

**LESSON:**
"Don't compete on the incumbent's terms.
 Reframe the decision criteria."

**CTA:**
"Ever competed against a giant? How'd you position?"

LENGTH: 500-700 words
TIME: 1 hour
FREQUENCY: 1× per week
```

### **LinkedIn Algorithm Optimization (Sales Tech):**

```
POST TIMING:
✅ Tuesday-Thursday, 9-11 AM EST (highest engagement)
✅ Avoid Monday AM (too busy), Friday PM (weekend mode)

For India market:
✅ Tuesday-Thursday, 9 AM-2 PM IST

POST LENGTH:
✅ 300-600 words (sweet spot for LinkedIn)
❌ <100 words (not enough depth)
❌ >800 words (tl;dr, save for newsletter)

ENGAGEMENT TACTICS:
□ First comment: Add value (not "What do you think?")
□ Reply to all comments within first hour (algorithm boost)
□ Ask specific question in CTA (not generic "Thoughts?")
□ Tag max 2 people (more = spam signal)
□ Use 3-5 hashtags max (Sales, SalesLeadership, B2BSales, etc.)

CAROUSEL STRATEGY (Sales Tech Specific):
When: Complex frameworks, multi-step processes, data visualization
Format: 7-10 slides
Structure:
- Slide 1: Hook (bold claim + data point)
- Slides 2-8: Framework/data (one point per slide)
- Slide 9: Summary (recap key points)
- Slide 10: CTA (apply this, share results)

Tools:
- Free: Canva (templates available)
- Paid: Taplio ($29/mo), Shield ($12/mo)
```

---
