#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
一人公司思维导师 / SoloMentor Hub
================================
三人思维顾问团：Pieter Levels + Sahil Lavingia + Justin Welsh
"""


class MentorHub:
    """思维导师Hub — 三位大佬视角整合"""

    # =========================================================================
    # 场景诊断
    # =========================================================================
    SCENARIOS = {
        "产品值不值得做": {
            "keywords": ["值不值得", "该不该做", "要不要做"],
            "levels": "两周做MVP，第一天收费。Twitter上公布。有人付费→继续，没人→下一个。",
            "sahil": "先找10个潜在用户，手工帮他们解决问题。10个人都说好→做产品。找不到10个人→我建议放弃。",
            "justin": "先发内容建立受众。免费输出价值。当有人私信问你'有解决方案吗'→做最小产品。",
        },
        "要不要融资": {
            "keywords": ["融资", "风投", "VC", "投资"],
            "levels": "No. 你的产品自己赚的钱够吃拉面了，你就不需要任何人的钱。",
            "sahil": "我拿了$800万，然后裁了75%的人。如果重来，我绝不融资。Bootstrap First。",
            "justin": "$1000万营收、89%利润率。我从没用过任何外部资金。不需要。",
        },
        "要不要雇人": {
            "keywords": ["雇人", "招聘", "团队", "全职", "用人"],
            "levels": "能不雇就不雇。我用AI写95%的代码。只在必须的时候找承包商。",
            "sahil": "No full-time employees. Only hourly contractors. No meetings. No deadlines.",
            "justin": "我一个人+老婆+1个VA做到$1000万。先问：能不能用系统替代人？能就不雇。",
        },
        "定价": {
            "keywords": ["定价", "收费", "价格", "多少钱"],
            "levels": "想一个合理价格→翻倍→上线。$9/月起步。80%情况下用户数不变收入翻倍。",
            "sahil": "算你的拉面预算。产品收入>拉面预算→你自由了。具体价格可以慢慢调。",
            "justin": "$50是信任价。从低价开始建立信任，再逐步引导到$150→$1000+。",
        },
        "内容vs产品": {
            "keywords": ["内容", "产品", "优先", "先后"],
            "levels": "当然是产品。做一个能收费的东西，放在网上。内容是用来展示产品的。",
            "justin": "当然是内容。先建立受众。没有受众的产品就像沙漠里的商店。",
            "sahil": "取决于你的起点。如果你已经是某领域的专家（有社区基础），做产品。如果你从零开始，先建立社区。",
        },
        "迷茫": {
            "keywords": ["迷茫", "不知道", "焦虑", "方向"],
            "levels": "做一个东西，任何东西。放上线，看看有没有人付钱。行动是最好的解药。",
            "sahil": "先接受这种感觉。我裁员后最惨的时候连我妈都不知道。找到你想服务的社区，浸泡进去。",
            "justin": "创业没有地图。这不是诅咒，是礼物。设定一个90天目标——只做一件事。发够90条内容。",
        },
    }

    # =========================================================================
    # 阶段导航
    # =========================================================================
    STAGES = {
        "阶段0：有想法但没开始": [
            "Sahil: 找到你想服务的社区，浸泡进去。不要推销，只帮忙只倾听。",
            "Justin: 每天发一条内容。先建立输出习惯。90天90条。",
        ],
        "阶段1：从0到第一个付费用户": [
            "Levels: Ship Fast + Charge First。两周MVP，上线收费。",
            "Justin: 免费内容→邮件列表→$50产品。先给价值，再收信任价。",
        ],
        "阶段2：月入$1000到$10000": [
            "Justin: Product Ladder。$50→$150→更多。每层验证后再升级。",
            "Levels: 翻倍价格测试天花板。80%情况下用户数不变，收入翻倍。",
        ],
        "阶段3：月入$1万到$10万": [
            "Sahil: 优先利润→减少工作时间→把自由放在第一位。",
            "Justin: Vertical Scale。不扩团队，提高单价+优化系统。",
        ],
        "阶段4：可持续经营": [
            "Sahil: Freedom at All Costs。每问'这让我更自由吗？'",
            "Justin: 停止做新东西。只优化现有的。合并不必要的产品线。",
        ],
    }

    # =========================================================================
    # 大佬速查卡
    # =========================================================================
    MENTOR_CARDS = {
        "levels": {
            "name": "Pieter Levels",
            "emoji": "🧑‍💻",
            "tagline": "Ship more. Talk less. Charge first.",
            "stats": "年入$400万 | 70+项目4个成功 | 零融资零员工",
            "strongest_on": ["产品决策", "定价", "技术选型", "快速验证"],
            "core_quote": "做出来，放上去，看有没有人付钱。",
            "weakness": "不适合需要深度研发的产品、已有PMF时应聚焦而非散弹",
        },
        "sahil": {
            "name": "Sahil Lavingia",
            "emoji": "🏛️",
            "tagline": "The future of work is not working.",
            "stats": "$800万VC→裁员75%→$1亿估值 | 每周工作<4小时",
            "strongest_on": ["战略决策", "融资判断", "团队架构", "定义成功"],
            "core_quote": "先盈利再讨论增长。$1利润>零利润的$1亿GMV。",
            "weakness": "需要前期资金的项目、极高网络效应的市场",
        },
        "justin": {
            "name": "Justin Welsh",
            "emoji": "📈",
            "tagline": "我不想成为最大的公司，我只想成为最自由的人。",
            "stats": "5年$1000万营收 | 89%利润率 | 零广告费",
            "strongest_on": ["内容增长", "变现漏斗", "定价阶梯", "受众建设"],
            "core_quote": "先免费输出价值95%，再推广5%。",
            "weakness": "需要独特实战经验做内容壁垒、不适合快速变现需求",
        },
    }

    @classmethod
    def diagnose(cls, question: str) -> str:
        """场景诊断 — 关键词路由到最匹配的场景"""
        question_lower = question.lower()
        result = ""

        matches = []
        for scenario_name, data in cls.SCENARIOS.items():
            if any(kw in question_lower or kw in question for kw in data["keywords"]):
                matches.append((scenario_name, data))

        if matches:
            for name, data in matches:
                result += f"## 场景诊断：{name}\n\n"
                result += f"### 🧑‍💻 Pieter Levels 会说：\n{data['levels']}\n\n"
                result += f"### 🏛️ Sahil Lavingia 会说：\n{data['sahil']}\n\n"
                result += f"### 📈 Justin Welsh 会说：\n{data['justin']}\n\n"
                result += "---\n\n"
            return result.strip()

        # 默认回应
        return (
            "## 请更具体地描述你的决策困境\n\n"
            "我可以帮你分析以下类型的问题：\n"
            "- 产品决策：这个值不值得做？\n"
            "- 定价决策：该收多少钱？\n"
            "- 增长决策：怎么获客？\n"
            "- 战略决策：要不要融资/雇人？\n"
            "- 方向迷茫：不知道下一步做什么\n"
        )

    @classmethod
    def get_stage_advice(cls, stage: str) -> str:
        """阶段导航"""
        advice = cls.STAGES.get(stage)
        if not advice:
            # 模糊匹配
            for key in cls.STAGES:
                if stage in key:
                    advice = cls.STAGES[key]
                    stage = key
                    break
        if not advice:
            advice = cls.STAGES["阶段0：有想法但没开始"]
            stage = "阶段0：有想法但没开始"

        result = f"## {stage}\n\n"
        for item in advice:
            result += f"- {item}\n"
        return result

    @classmethod
    def get_mentor_card(cls, mentor: str) -> str:
        """大佬速查卡"""
        card = cls.MENTOR_CARDS.get(mentor.lower())
        if not card:
            return "支持的大佬：levels / sahil / justin"

        return (
            f"## {card['emoji']} {card['name']}\n\n"
            f"> {card['tagline']}\n\n"
            f"**数据**：{card['stats']}\n\n"
            f"**最强领域**：{', '.join(card['strongest_on'])}\n\n"
            f"**核心语录**：{card['core_quote']}\n\n"
            f"**局限**：{card['weakness']}\n"
        )

    @classmethod
    def compare_mentors(cls, topic: str = "定价") -> str:
        """三位大佬对比表"""
        comparisons = {
            "定价": {
                "levels": "想一个价格→翻倍→上线。$9/月起步。",
                "sahil": "算拉面预算→覆盖→自由。",
                "justin": "$50信任价→$150价值→$1000+系统。",
            },
            "产品策略": {
                "levels": "Shotgun：做大量小产品，5%成功率。",
                "sahil": "Community-First：先泡社区找需求。",
                "justin": "Product Ladder：逐层验证，不跳级。",
            },
            "增长方式": {
                "levels": "Build in Public：边做边分享。",
                "sahil": "透明度=营销：公开一切数据。",
                "justin": "Content Flywheel：内容→受众→信任→购买。",
            },
        }

        comp = comparisons.get(topic, comparisons["定价"])
        result = f"## 三位大佬 × {topic}\n\n"
        result += "| 大佬 | 策略 |\n|------|------|\n"
        result += f"| 🧑‍💻 Levels | {comp['levels']} |\n"
        result += f"| 🏛️ Sahil | {comp['sahil']} |\n"
        result += f"| 📈 Justin | {comp['justin']} |\n"
        return result


def main():
    print("=" * 70)
    print("一人公司思维导师 / SoloMentor Hub")
    print("三人思维顾问团：Levels | Sahil | Justin")
    print("=" * 70)
    print()

    # 演示1：场景诊断
    print("【演示1】场景诊断：我想做个记账App，值不值得？")
    print("-" * 70)
    print(MentorHub.diagnose("该不该做记账App"))
    print()

    # 演示2：定价诊断
    print("【演示2】场景诊断：产品该定多少钱？")
    print("-" * 70)
    print(MentorHub.diagnose("定价多少合适"))
    print()

    # 演示3：阶段导航
    print("【演示3】阶段导航：从0到第一个付费用户")
    print("-" * 70)
    print(MentorHub.get_stage_advice("阶段1：从0到第一个付费用户"))
    print()

    # 演示4：大佬速查卡
    print("【演示4】大佬速查卡：Pieter Levels")
    print("-" * 70)
    print(MentorHub.get_mentor_card("levels"))
    print()

    # 演示5：对比表
    print("【演示5】三位大佬 × 增长方式对比")
    print("-" * 70)
    print(MentorHub.compare_mentors("增长方式"))
    print()

    print("=" * 70)
    print("三人顾问团就绪。随时为一人公司创业者提供多视角决策参考。")
    print("=" * 70)


if __name__ == "__main__":
    main()
