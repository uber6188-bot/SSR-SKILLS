---
name: seo-blog-writer
description: |
  Fully automated SEO article writer. Give it a topic and domain — it handles
  everything: auto-discovers product context, researches keywords, analyzes
  competitors, writes the article, verifies links, and delivers a complete
  publication package (article + QA report + schema markup + promotion checklist).
  One confirmation gate before writing starts, then hands-off execution.
  Works for any site, any industry, any CMS. No hardcoded dependencies.
---

# AI-Driven SEO Blog Writer

> **Long-running task mode.** This skill generates a multi-phase artifact. Before Phase 0: create a `task-logs/{slug}/` workspace, write each phase output to disk incrementally, and use offset reads to verify writes. This ensures crash-safe, resumable execution without regenerating completed work.

## Design Principles

1. **Research-first**: Never write without understanding the topic, audience, and competition
2. **Verification-first**: All statistics and claims must be verifiable before inclusion
3. **Brand-aligned**: Output must match the target brand voice and style
4. **SEO-native**: Content optimized for both humans and search engines from the start
5. **Quality-gated**: Multi-dimensional scoring before delivery

## Execution Model

6-phase pipeline: Context Discovery → Research Brief → Content Generation → AI Pattern Prevention → Quality Assurance → Delivery

Each phase has checkpoints. User confirms at Phase 0.5 (Discovery Gate) before writing begins.

## Failure Recovery

- Network/search failures → retry 3x, then use cached data
- Missing context → ask user at Discovery Gate
- Quality score < 70 → auto-revise before delivery
- Link verification fails → flag in QA report, suggest alternatives

## Quick Start

**Input:** Topic + target domain (e.g., "Write a blog post about project management software for example.com")

**Process:** Auto-discovers product context → researches keywords → analyzes competitors → writes article → verifies links → delivers package

**Output:** Article + QA report + schema markup + promotion checklist

**One gate:** User confirms discovery results before writing starts.

## Execution Modes

| Mode | Description | Best For |
|------|-------------|----------|
| Full Auto | Complete pipeline, no intervention | Standard articles |
| Guided | Checkpoints at each phase | Complex/regulated topics |
| Quick | Skip deep research, write immediately | Time-sensitive content |

## Phase 0: Context Discovery (Automated)

**Auto-discovers:**
- Product/service context from domain analysis
- Existing blog content and structure
- Target keywords (with honest difficulty estimation)
- Competitor content analysis

**Skip check:** If user provides all context upfront, skip discovery.

## Phase 0.5: Discovery Confirmation Gate (MANDATORY)

Display discovery results and ask user to confirm before proceeding:
- Product context summary
- Target keywords with difficulty scores
- Competitor analysis highlights
- Proposed article structure

User can: ✅ Confirm | ✏️ Edit | 🔄 Re-discover

## Phase 0.6: Fallback Questionnaire

If discovery is incomplete, ask user:
1. Product/service description (1-2 sentences)
2. Target audience (who reads this?)
3. Primary keyword (what should this rank for?)
4. Competitor URLs (2-3 examples)

Optional: Brand guidelines, content strategy.

## Phase 1: Research Brief Generation

**1.1 Article Blueprint:** Structure based on topic type (comparison/how-to/list/guide)

**1.2 Linking Strategy:** Internal links (existing content) + external links (authoritative sources)

**1.3 Research Brief Output:** Article spec + competition analysis + linking plan + brand guidelines

## Article Specification

```
Article Type: [comparison/how-to/list/guide]
Target Length: [word count]
Primary Keyword: [keyword]
Secondary Keywords: [list]
Target Audience: [persona]
Competitor URLs: [list]
```

## Phase 2: Content Generation

**2.1 Opening:** Hook in first 100 words — problem statement + promise

**2.2 Body Standards:**
- H2/H3 hierarchy with keyword-rich headers
- Short paragraphs (2-3 sentences)
- Bullet points and tables for scanability
- Internal links every 300 words
- External links to authoritative sources

**2.3 Statistics:** All claims verified before inclusion. Unverifiable claims flagged.

**2.4 GEO Optimization:** Platform-specific formatting (featured snippets, People Also Ask)

**2.5 Linking Execution:** Internal links contextual, external links to high-authority domains

## Phase 3: AI Pattern Prevention & Brand Voice

**3.1 AI Pattern Detection:** Remove filler words, overly formal language, generic phrases

**3.2 Brand Voice Calibration:** Match target tone (professional/casual/technical)

**3.3 Authenticity Verification:** Ensure content sounds human, not AI-generated

## Phase 4: Quality Assurance

**4.1 Link Verification:** All links checked — 200 OK, correct anchor text

**4.2 Quality Scoring:** Multi-dimensional (SEO/readability/originality/brand alignment)

**4.3 Factual Accuracy:** Statistics and claims cross-referenced

**4.4 Quality Report:** Score breakdown + critical issues + warnings + optimization suggestions

## Phase 5: Delivery Package

**5.1 Finalization:** Clean formatting, proper headings, meta description, schema markup

**5.2 Deliverables:**
- Published article (markdown + HTML)
- QA report with quality scores
- Schema markup (Article/FAQ/HowTo)
- Promotion checklist (social posts, outreach templates)
- Success metrics setup (tracking recommendations)

## Error Handling

**Graceful degradation:** If any phase fails, deliver partial results with clear status indicators.

| Failure | Fallback |
|---------|----------|
| Search API down | Use cached research data |
| Link verification fails | Flag in report, suggest alternatives |
| Quality score < 70 | Auto-revise before delivery |
| User doesn't confirm gate | Pause and wait |

## Examples & Use Cases

See `skill-card.md` for detailed examples of SaaS comparison, how-to guide, and alternatives page articles.

## Related Skills

- `content-research-writer` — Deep research and writing
- `blog-seo-writer` — SEO-optimized blog posts
- `content-quality-auditor` — Content quality scoring

